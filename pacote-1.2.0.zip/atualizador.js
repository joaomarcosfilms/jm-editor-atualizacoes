/* JM Editor — atualização automática.
 * Ao abrir (e a cada 6 h) o painel pergunta ao site de atualizações se há versão nova.
 * SEGURANÇA: só instala pacote cuja assinatura Ed25519 (chave privada só no Mac do João) confere com a
 * chave pública abaixo, e cujo SHA-256 bate com o assinado. Site invadido ou arquivo trocado = recusado.
 * Funciona em dois contextos: dentro do painel (liga a interface) e no Node puro (exporta funções p/ teste). */
(function (root) {
  'use strict';
  var req = (typeof require !== 'undefined') ? require : (root.cep_node && root.cep_node.require);
  if (!req) return;
  var fs = req('fs'), path = req('path'), os = req('os'), crypto = req('crypto'), cp = req('child_process');
  var https = req('https'), http = req('http');

  var URL_PADRAO = 'https://raw.githubusercontent.com/joaomarcosfilms/jm-editor-atualizacoes/main';
  var CHAVE_PUBLICA = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEA+qYdpu7S2pJIEYYhe37Njis+xtmWcQal8GyUlv9H4bw=\n-----END PUBLIC KEY-----\n';
  var MAX_JSON = 20000, MAX_ZIP = 8 * 1024 * 1024;

  // Endereço: o padrão; para TESTE local existe ~/.jm-ponte/atualizacao-url-teste.txt (a assinatura continua obrigatória).
  function urlBase() {
    try {
      var t = fs.readFileSync(path.join(os.homedir(), '.jm-ponte', 'atualizacao-url-teste.txt'), 'utf8').trim();
      if (permitido(t)) return t.replace(/\/+$/, '');
    } catch (e) {}
    return URL_PADRAO;
  }
  function permitido(u) {
    var p; try { p = new URL(String(u)); } catch (e) { return false; }
    return p.protocol === 'https:' || (p.protocol === 'http:' && (p.hostname === '127.0.0.1' || p.hostname === 'localhost'));
  }
  function baixar(u, max, redirs) {
    return new Promise(function (ok, falha) {
      if (!permitido(u)) return falha(new Error('endereço não permitido'));
      var lib = u.indexOf('https:') === 0 ? https : http;
      var r = lib.get(u, { timeout: 15000, headers: { 'User-Agent': 'JM-Editor-atualizador', 'Cache-Control': 'no-cache' } }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && (redirs || 0) < 3) {
          res.resume(); return ok(baixar(new URL(res.headers.location, u).href, max, (redirs || 0) + 1));
        }
        if (res.statusCode !== 200) { res.resume(); return falha(new Error('o site respondeu ' + res.statusCode)); }
        var partes = [], total = 0;
        res.on('data', function (d) { total += d.length; if (total > max) { r.destroy(new Error('arquivo grande demais')); return; } partes.push(d); });
        res.on('end', function () { ok(Buffer.concat(partes)); });
        res.on('error', falha);
      });
      r.on('timeout', function () { r.destroy(new Error('sem resposta do site')); });
      r.on('error', falha);
    });
  }
  function parseV(v) { var m = /^(\d+)\.(\d+)\.(\d+)$/.exec(String(v)); return m ? [+m[1], +m[2], +m[3]] : null; }
  function maior(a, b) {
    var x = parseV(a), y = parseV(b); if (!x || !y) return false;
    for (var i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i];
    return false;
  }
  function assinaturaOk(info, chave) {
    if (!info || !parseV(info.versao) || !/^[0-9a-f]{64}$/.test(String(info.sha256)) || typeof info.assinatura !== 'string') return false;
    var msg = Buffer.from('jm-editor\n' + info.versao + '\n' + info.sha256 + '\n' + (info.requer_instalador ? '1' : '0'));
    try { return crypto.verify(null, msg, chave || CHAVE_PUBLICA, Buffer.from(info.assinatura, 'base64')); } catch (e) { return false; }
  }
  function exec(cmd, args) {
    return new Promise(function (ok, falha) {
      cp.execFile(cmd, args, { timeout: 60000 }, function (e, so, se) { if (e) falha(new Error(cmd + ': ' + (se || e.message))); else ok(so); });
    });
  }
  function lerVersao(raiz) {
    try { return JSON.parse(fs.readFileSync(path.join(raiz, 'VERSAO.json'), 'utf8')).versao || '0.0.0'; } catch (e) { return '0.0.0'; }
  }

  async function verificar(versaoLocal, chave) {
    var base = urlBase();
    var buf = await baixar(base + '/latest.json?t=' + Date.now(), MAX_JSON);
    var info = JSON.parse(buf.toString('utf8'));
    if (!assinaturaOk(info, chave)) throw new Error('assinatura da atualização não confere: ignorada');
    return { base: base, info: info, nova: maior(info.versao, versaoLocal) };
  }

  async function instalar(base, info, raiz, aoPasso, chave) {
    if (!assinaturaOk(info, chave)) throw new Error('assinatura da atualização não confere: ignorada');
    var dir = path.join(os.homedir(), '.jm-ponte', 'atualizacao');
    var trab = path.join(dir, 'v' + info.versao), novo = path.join(trab, 'novo');
    await exec('/bin/rm', ['-rf', trab]);
    fs.mkdirSync(trab, { recursive: true });
    aoPasso && aoPasso('Baixando a versão ' + info.versao + '…');
    var zip = await baixar(base + '/pacote-' + info.versao + '.zip', MAX_ZIP);
    if (crypto.createHash('sha256').update(zip).digest('hex') !== info.sha256) throw new Error('o pacote baixado não confere com a assinatura: descartado');
    var zp = path.join(trab, 'pacote.zip');
    fs.writeFileSync(zp, zip);
    aoPasso && aoPasso('Conferindo o pacote…');
    await exec('/usr/bin/ditto', ['-x', '-k', zp, novo]);
    if (!fs.existsSync(path.join(novo, 'CSXS', 'manifest.xml')) || !fs.existsSync(path.join(novo, 'painel.js'))) throw new Error('pacote incompleto');
    if (lerVersao(novo) !== info.versao) throw new Error('a versão dentro do pacote não é a anunciada');
    aoPasso && aoPasso('Guardando a versão anterior…');
    var bk = path.join(dir, 'anterior-' + lerVersao(raiz) + '-' + Date.now());
    await exec('/usr/bin/ditto', [raiz, bk]);
    aoPasso && aoPasso('Instalando…');
    await exec('/usr/bin/ditto', [novo, raiz]);
    // mantém só os 3 backups mais recentes
    try {
      var velhos = fs.readdirSync(dir).filter(function (n) { return n.indexOf('anterior-') === 0; }).sort();
      velhos.slice(0, Math.max(0, velhos.length - 3)).forEach(function (n) { try { cp.execFileSync('/bin/rm', ['-rf', path.join(dir, n)]); } catch (e) {} });
      cp.execFileSync('/bin/rm', ['-rf', trab]);
    } catch (e) {}
    return { backup: bk, versao: info.versao };
  }

  var API = { verificar: verificar, instalar: instalar, assinaturaOk: assinaturaOk, maior: maior, lerVersao: lerVersao, urlBase: urlBase };

  // ---------- interface (só dentro do painel) ----------
  var doc = root.document;
  if (!doc || !doc.getElementById('atualizacao')) { if (typeof module !== 'undefined' && module.exports) module.exports = API; return; }
  var $ = function (id) { return doc.getElementById(id); };
  var cep = root.__adobe_cep__;
  var raiz;
  try { raiz = decodeURI(cep.getSystemPath('extension')).replace(/^file:\/\//, ''); } catch (e) { raiz = path.dirname(decodeURI(root.location.pathname)); }
  var local = lerVersao(raiz), achada = null, instalada = false;
  $('versao-txt').textContent = 'v' + local;

  function ocupado() { return $('cancelar') && $('cancelar').className === 'on'; }
  function mostrar(texto, botao, cls) {
    var b = $('atualizacao'); b.style.display = 'flex'; b.className = cls || '';
    $('atu-texto').textContent = texto;
    $('atu-botao').style.display = botao ? 'inline-block' : 'none';
    if (botao) $('atu-botao').textContent = botao;
  }
  async function procurar(manual) {
    if (instalada) return;
    try {
      var r = await verificar(local);
      if (r.nova) {
        achada = r;
        var notas = r.info.notas ? ' — ' + String(r.info.notas).slice(0, 140) : '';
        if (r.info.requer_instalador) mostrar('Versão ' + r.info.versao + ' disponível' + notas + '. Ela precisa do instalador novo: peça o zip ao João.', null, '');
        else mostrar('Atualização ' + r.info.versao + ' disponível' + notas, 'Atualizar agora', '');
      } else if (manual) { mostrar('Você já está na versão mais nova (' + local + ').', null, 'ok'); setTimeout(function () { if (!achada) $('atualizacao').style.display = 'none'; }, 4000); }
    } catch (e) { if (manual) mostrar('Não consegui verificar agora: ' + e.message, null, 'erro'); }
  }
  async function aplicar() {
    if (!achada || instalada) return;
    if (ocupado()) { mostrar('Espere a edição terminar para atualizar.', null, 'erro'); return; }
    $('atu-botao').disabled = true;
    try {
      var r = await instalar(achada.base, achada.info, raiz, function (t) { mostrar(t, null, ''); });
      instalada = true;
      mostrar('✓ Atualizado para ' + r.versao + '. Salve o projeto, feche e abra o Premiere para usar a versão nova.', null, 'ok');
    } catch (e) {
      mostrar('Não atualizei: ' + e.message + ' (nada foi trocado).', 'Tentar de novo', 'erro');
    } finally { $('atu-botao').disabled = false; }
  }
  $('atu-botao').addEventListener('click', aplicar);
  $('atu-verificar').addEventListener('click', function () { procurar(true); });
  setTimeout(function () { procurar(false); }, 2500);
  setInterval(function () { procurar(false); }, 6 * 3600 * 1000);
})(typeof window !== 'undefined' ? window : globalThis);

/* JM Ponte: servidor local dentro do Premiere.
 * O Claude manda ExtendScript por HTTP (só neste computador, com senha) e o Premiere executa.
 *   POST /jsx   corpo = código ExtendScript  ->  {"ok":true,"v":...} ou {"ok":false,"erro":...}
 *   GET  /ping  ->  informações do Premiere e do projeto aberto
 * A senha fica em ~/.jm-ponte/token (só o dono lê). Porta fixa 5188.
 */
(function () {
  'use strict';
  var PORTA = 5188;
  var el = function (id) { return document.getElementById(id); };
  function estado(texto, cls, detalhe) {
    el('estado').textContent = texto;
    el('luz').className = 'luz ' + (cls || '');
    if (detalhe !== undefined) el('detalhe').textContent = detalhe;
  }
  function ultimo(t) { el('ultimo').textContent = t; }

  var req = (typeof require !== 'undefined') ? require : (window.cep_node && window.cep_node.require);
  if (!req) { estado('Node desligado no painel', 'erro', 'O manifest precisa de --enable-nodejs.'); return; }
  var http = req('http'), fs = req('fs'), os = req('os'), path = req('path'), crypto = req('crypto');
  var cep = window.__adobe_cep__;
  if (!cep || !cep.evalScript) { estado('Sem ponte com o Premiere', 'erro', 'window.__adobe_cep__ ausente.'); return; }

  var DIR = path.join(os.homedir(), '.jm-ponte');
  var TOKEN_ARQ = path.join(DIR, 'token');
  var token;
  try {
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { mode: 448 });
    if (fs.existsSync(TOKEN_ARQ)) token = fs.readFileSync(TOKEN_ARQ, 'utf8').trim();
    if (!token || token.length < 32) {
      token = crypto.randomBytes(24).toString('hex');
      fs.writeFileSync(TOKEN_ARQ, token + '\n', { mode: 384 });
    }
    try { fs.chmodSync(TOKEN_ARQ, 384); } catch (e) { /* ok */ }
  } catch (e) { estado('Sem acesso a ~/.jm-ponte', 'erro', String(e)); return; }

  // Um comando por vez no Premiere.
  var fila = [];
  var rodando = false;
  function proximo() {
    if (rodando || !fila.length) return;
    rodando = true;
    var item = fila.shift();
    var fim = false;
    var relogio = setTimeout(function () {
      if (fim) return; fim = true; rodando = false;
      item.cb('{"ok":false,"erro":"tempo esgotado esperando o Premiere (o comando pode ainda estar rodando)"}');
      proximo();
    }, item.limite);
    cep.evalScript('JM_run(' + JSON.stringify(item.codigo) + ')', function (r) {
      if (fim) return; fim = true; clearTimeout(relogio); rodando = false;
      item.cb(r);
      proximo();
    });
  }
  function executar(codigo, limite, cb) { fila.push({ codigo: codigo, limite: limite, cb: cb }); proximo(); }

  function resp(res, status, corpo) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(corpo);
  }

  var servidor = http.createServer(function (rq, res) {
    var host = String(rq.headers.host || '');
    if (host !== '127.0.0.1:' + PORTA && host !== 'localhost:' + PORTA) return resp(res, 403, '{"ok":false,"erro":"host"}');
    if (rq.headers['origin']) return resp(res, 403, '{"ok":false,"erro":"origem"}'); // navegador não pode chamar
    if (rq.headers['x-jm-token'] !== token) return resp(res, 401, '{"ok":false,"erro":"senha"}');

    if (rq.method === 'GET' && rq.url === '/ping') {
      return executar('JM.info()', 15000, function (r) { resp(res, 200, r); });
    }
    if (rq.method === 'POST' && rq.url.split('?')[0] === '/jsx') {
      var partes = [], tam = 0;
      rq.on('data', function (c) { tam += c.length; if (tam > 5e6) { rq.destroy(); } else partes.push(c); });
      rq.on('end', function () {
        var codigo = Buffer.concat(partes).toString('utf8');
        var q = rq.url.indexOf('?limite=') >= 0 ? parseInt(rq.url.split('?limite=')[1], 10) : 120;
        var limite = Math.min(Math.max(q || 120, 5), 1800) * 1000;
        ultimo('Último comando: ' + new Date().toLocaleTimeString() + ' (' + codigo.length + ' bytes)');
        executar(codigo, limite, function (r) { resp(res, 200, r || '{"ok":false,"erro":"resposta vazia"}'); });
      });
      return;
    }
    resp(res, 404, '{"ok":false,"erro":"rota"}');
  });

  servidor.on('error', function (e) {
    if (e.code === 'EADDRINUSE') estado('Ponte ativa em outra instância', 'ok', 'Porta ' + PORTA + ' já está em uso pela JM Ponte (tudo certo).');
    else estado('Erro ao ligar', 'erro', String(e));
  });
  servidor.listen(PORTA, '127.0.0.1', function () {
    try { fs.writeFileSync(path.join(DIR, 'porta'), String(PORTA) + '\n'); } catch (e) { /* ok */ }
    estado('Ponte ligada', 'ok', '127.0.0.1:' + PORTA + ' · só este computador');
  });
})();

#!/usr/bin/env python3
"""Analisa um vídeo falado e prepara a edição do João para o Premiere.

Gera, numa pasta de trabalho (NUNCA ao lado do original):
  plano.json        trechos a manter (corte seco), zoom por trecho, palavras já no tempo da timeline
  transcricao.txt   texto com tempos, para o Claude revisar nomes antes de legendar
  legendas.srt      legendas em blocos curtos, no tempo da timeline (depois dos cortes)

Uso:
  analisar.py VIDEO [--saida PASTA] [--modelo small|medium] [--limiar-db 27] [--zoom 1.12] [--sem-zoom]
  analisar.py --so-srt PASTA/plano.json      refaz o .srt depois de corrigir palavras no plano.json

Regras de corte (jm-vision-edicao + notas do Cérebro):
  - cortar pelo SINAL DE ÁUDIO (pico da voz - limiar dB), não pelo tempo do Whisper;
  - sem silêncio, sem vícios (hum, ahn, ééé), sem gagueira, e em retake vale a ÚLTIMA tentativa;
  - pausa >= 0,42 s vira ~0,24 s de respiração; pausa menor fica natural (sem corte).
"""
import argparse, difflib, json, os, re, shutil, subprocess, sys, time, unicodedata, wave
import numpy as np

HOME = os.path.expanduser('~')
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def achar(nome):
    for c in (shutil.which(nome), HOME + '/.jm-ponte/bin/' + nome, '/opt/homebrew/bin/' + nome, '/usr/local/bin/' + nome):
        if c and os.path.exists(c):
            return c
    sys.exit('não achei %s (instale com: brew install ffmpeg)' % nome)


def norm(s):
    s = unicodedata.normalize('NFD', s.lower())
    return re.sub(r'[^a-z0-9 ]', '', ''.join(c for c in s if unicodedata.category(c) != 'Mn')).strip()


def sonda(video):
    j = json.loads(subprocess.check_output([achar('ffprobe'), '-v', 'error', '-print_format', 'json',
                                            '-show_streams', '-show_format', video]))
    v = next(s for s in j['streams'] if s['codec_type'] == 'video')
    num, den = v['r_frame_rate'].split('/')
    rot = 0
    for sd in v.get('side_data_list', []):
        if 'rotation' in sd:
            rot = int(sd['rotation'])
    w, h = int(v['width']), int(v['height'])
    if abs(rot) in (90, 270):
        w, h = h, w
    return dict(largura=w, altura=h, fps=float(num) / float(den), rotacao=rot,
                duracao=float(j['format']['duration']), codec=v['codec_name'],
                tem_audio=any(s['codec_type'] == 'audio' for s in j['streams']))


def extrair_audio(video, wav, de=0.0, ate=None):
    cmd = [achar('ffmpeg'), '-y', '-v', 'error']
    if de and de > 0:
        cmd += ['-ss', '%.3f' % de]
    if ate is not None:
        cmd += ['-t', '%.3f' % max(0.1, ate - (de or 0.0))]
    subprocess.check_call(cmd + ['-i', video, '-vn', '-ac', '1', '-ar', '16000', wav])
    with wave.open(wav) as w:
        return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0, w.getframerate()


def regioes_de_voz(x, sr, limiar_db, junta=0.18, antes=0.07, depois=0.05, minimo=0.10):
    passo = int(sr * 0.02)
    n = len(x) // passo
    rms = np.sqrt((x[:n * passo].reshape(n, passo) ** 2).mean(axis=1) + 1e-12)
    db = 20 * np.log10(rms)
    pico = np.percentile(db, 99)
    ativo = db > (pico - limiar_db)
    regs, ini = [], None
    for i, a in enumerate(ativo):
        if a and ini is None:
            ini = i
        elif not a and ini is not None:
            regs.append([ini * 0.02, i * 0.02]); ini = None
    if ini is not None:
        regs.append([ini * 0.02, n * 0.02])
    out = []
    for r in regs:  # une lacunas pequenas
        if out and r[0] - out[-1][1] < junta:
            out[-1][1] = r[1]
        else:
            out.append(r)
    dur = len(x) / sr
    return [[max(0, a - antes), min(dur, b + depois)] for a, b in out if b - a >= minimo], float(pico)


def transcrever(wav, modelo, glossario, prompt=None):
    from faster_whisper import WhisperModel
    m = WhisperModel(modelo, device='cpu', compute_type='int8')
    # Sem initial_prompt por padrão: o modelo small repete o prompt como se fosse fala (visto em teste).
    # Nomes próprios são corrigidos depois pelo glossario.json.
    segs, _ = m.transcribe(wav, language='pt', word_timestamps=True, vad_filter=False,
                           initial_prompt=prompt, condition_on_previous_text=False)
    palavras = []
    for s in segs:
        for w in (s.words or []):
            palavras.append(dict(t0=round(w.start, 3), t1=round(w.end, 3), w=w.word.strip()))
    return palavras


VICIOS = {'ah', 'ahn', 'ahm', 'hum', 'hm', 'hmm', 'eh', 'ehn', 'ehm', 'uh', 'uhm', 'aham', 'ahan'}


def e_vicio(p):
    n = norm(p)
    return n in VICIOS or bool(re.fullmatch(r'e{2,}|a{2,}h*|h+m+', n))


def marcar_remocoes(pal):
    """Devolve (lista de intervalos a remover, relatório). Mantém sempre a última tentativa."""
    rem, rel = [], []
    for p in pal:
        if e_vicio(p['w']):
            rem.append((p['t0'], p['t1'])); rel.append(('vício', p['w'], p['t0']))
    for i in range(len(pal) - 1):  # gagueira: palavra repetida colada
        a, b = pal[i], pal[i + 1]
        if norm(a['w']) and norm(a['w']) == norm(b['w']) and b['t0'] - a['t1'] < 0.6 and not e_vicio(a['w']):
            rem.append((a['t0'], a['t1'])); rel.append(('repetida', a['w'], a['t0']))
    # retake: frase parecida logo depois -> some a anterior
    frases, atual = [], []
    for i, p in enumerate(pal):
        if atual and p['t0'] - atual[-1]['t1'] >= 0.7:
            frases.append(atual); atual = []
        atual.append(p)
    if atual:
        frases.append(atual)
    for i, f in enumerate(frases):
        ta = norm(' '.join(p['w'] for p in f))
        if len(ta.split()) < 3:
            continue
        for g in frases[i + 1:i + 4]:
            if g[0]['t0'] - f[-1]['t1'] > 25:
                break
            tb = norm(' '.join(p['w'] for p in g))
            igual_inicio = ta.split()[:3] == tb.split()[:3]
            if igual_inicio or difflib.SequenceMatcher(None, ta, tb).ratio() >= 0.62:
                rem.append((f[0]['t0'] - 0.02, f[-1]['t1'] + 0.05)); rel.append(('retake', ' '.join(p['w'] for p in f), f[0]['t0']))
                break
    return rem, rel


def subtrair(regs, rem):
    out = []
    for a, b in regs:
        pedacos = [[a, b]]
        for ra, rb in rem:
            novo = []
            for x, y in pedacos:
                if rb <= x or ra >= y:
                    novo.append([x, y])
                else:
                    if ra > x: novo.append([x, ra])
                    if rb < y: novo.append([rb, y])
            pedacos = novo
        out += pedacos
    return [r for r in out if r[1] - r[0] >= 0.15]


def montar_trechos(regs, dur, fps, pausa_natural=0.42, respiro=0.24):
    # pausa curta fica natural (junta); pausa longa vira corte com respiro
    t = []
    for r in regs:
        if t and r[0] - t[-1][1] < pausa_natural:
            t[-1][1] = r[1]
        else:
            t.append(list(r))
    for i in range(len(t) - 1):
        folga = min(respiro / 2, (t[i + 1][0] - t[i][1]) / 2)
        t[i][1] += folga; t[i + 1][0] -= folga
    g = 1.0 / fps
    snap = lambda s: round(round(s / g) * g, 4)
    out = []
    for a, b in t:
        a, b = snap(max(0, a)), snap(min(dur, b))
        if out and a < out[-1][1]:
            a = out[-1][1]
        if b - a >= 0.15:
            out.append([a, b])
    return out


def tempo_timeline(trechos, t):
    for tr in trechos:
        if tr['de'] - 0.001 <= t <= tr['ate'] + 0.001:
            return tr['tl_inicio'] + (t - tr['de'])
    return None


def aplicar_glossario(texto, glossario):
    for pad, sub in glossario.get('trocas', {}).items():
        texto = re.sub(pad, sub, texto, flags=re.I)
    return texto


def gerar_srt(plano, glossario, caminho):
    pal = [p for p in plano['palavras'] if p.get('tl0') is not None]
    blocos, atual = [], []
    for p in pal:
        quebra = atual and (len(atual) >= 4 or p['tl0'] - atual[-1]['tl1'] > 0.35 or re.search(r'[.!?]$', atual[-1]['w']))
        if quebra:
            blocos.append(atual); atual = []
        atual.append(p)
    if atual:
        blocos.append(atual)

    def ts(s):
        s = max(0, s); h = int(s // 3600); m = int(s % 3600 // 60); ss = s % 60
        return ('%02d:%02d:%06.3f' % (h, m, ss)).replace('.', ',')
    linhas = []
    for i, b in enumerate(blocos):
        ini = b[0]['tl0']; fim = max(b[-1]['tl1'], ini + 0.4)
        if i + 1 < len(blocos):
            fim = min(fim, blocos[i + 1][0]['tl0'] - 0.01)
        fim = max(fim, ini + 0.2)
        texto = aplicar_glossario(' '.join(p['w'] for p in b), glossario)
        linhas.append('%d\n%s --> %s\n%s\n' % (i + 1, ts(ini), ts(fim), texto))
    with open(caminho, 'w', encoding='utf-8') as f:
        f.write('\n'.join(linhas))
    return len(blocos)


def batidas(x, sr, de):
    """Tempo (s, na linha do tempo da mídia) das batidas da música + andamento + confiança. Só numpy.
    x = áudio mono já recortado na faixa; de = início da faixa na mídia."""
    hop, nfft = 256, 1024
    if len(x) < nfft * 8:
        return [], 0.0, 0.0
    jan = np.hanning(nfft)
    n = (len(x) - nfft) // hop
    quadros = np.lib.stride_tricks.as_strided(x, shape=(n, nfft), strides=(x.strides[0] * hop, x.strides[0]))
    mag = np.log1p(10 * np.abs(np.fft.rfft(quadros * jan, axis=1)))
    fluxo = np.maximum(0, np.diff(mag, axis=0)).sum(axis=1)
    env = fluxo - np.convolve(fluxo, np.ones(31) / 31, mode='same')  # tira a tendência
    env = np.maximum(env, 0)
    if env.std() < 1e-6:
        return [], 0.0, 0.0
    passo = hop / float(sr)                              # s por quadro do envelope
    ac = np.correlate(env - env.mean(), env - env.mean(), mode='full')[len(env) - 1:]
    ac = ac / (ac[0] + 1e-12)
    lmin, lmax = int(60.0 / 190 / passo), int(60.0 / 60 / passo)
    lmax = min(lmax, len(ac) - 2)
    if lmax <= lmin + 2:
        return [], 0.0, 0.0
    lags = np.arange(lmin, lmax + 1)
    bpm = 60.0 / (lags * passo)
    peso = np.exp(-0.5 * (np.log2(bpm / 120.0) / 0.9) ** 2)   # prefere andamentos perto de 120
    pontos = ac[lags] * peso
    k = int(lags[np.argmax(pontos)])
    # refina o período (parábola) e mede a confiança (picos de ac nos múltiplos)
    a0, a1, a2 = ac[k - 1], ac[k], ac[k + 1]
    d = (a0 - 2 * a1 + a2)
    k_f = k + (0.5 * (a0 - a2) / d if abs(d) > 1e-9 else 0.0)
    # confiança: força do pico do período contra o ruído da autocorrelação (1 = muito rítmico)
    base = float(np.median(np.abs(ac[lmin:lmax + 1])))
    conf = max(0.0, min(1.0, (float(ac[k]) - base) / 0.5))
    periodo = k_f * passo
    # fase: onde cai a batida
    melhor, fase = -1.0, 0.0
    for f in np.linspace(0, k_f, 24, endpoint=False):
        idx = np.arange(f, len(env) - 1, k_f)
        v = np.interp(idx, np.arange(len(env)), env).sum() / max(1, len(idx))
        if v > melhor:
            melhor, fase = v, f
    centro = nfft / 2.0 / sr                              # o quadro mede a janela inteira: o som está no meio dela
    ts = [de + centro + (fase + m * k_f) * passo for m in range(int((len(env) - fase) / k_f))]
    return ts, 60.0 / periodo, conf


def movimento(video, de, ate):
    """Energia de mudança entre quadros (scene score do ffmpeg, imagem pequena): [(tempo_na_mídia, valor)]."""
    cmd = [achar('ffmpeg'), '-v', 'error', '-nostats']
    if de > 0:
        cmd += ['-ss', '%.3f' % de]
    cmd += ['-t', '%.3f' % max(0.1, ate - de), '-i', video, '-an',
            '-vf', "scale=160:-2,select='gte(scene,0)',metadata=print:key=lavfi.scene_score:file=-", '-f', 'null', '-']
    saida = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, universal_newlines=True).stdout
    pares, t = [], None
    for linha in saida.splitlines():
        m = re.search(r'pts_time:([0-9.]+)', linha)
        if m:
            t = float(m.group(1)) + de
        m = re.search(r'scene_score=([0-9.]+)', linha)
        if m and t is not None:
            pares.append((t, float(m.group(1))))
    return pares


def trechos_sem_fala(video, de, ate, fps, max_plano, wav=None, usar_batida=True, alvo=0.0, minimo=0.6):
    """Vídeo sem fala.
    1) grade de cortes: na batida da música (a cada K batidas ~ max_plano s) ou, sem ritmo claro, a cada max_plano s;
    2) o tempo NÃO é removido entre pedaços vizinhos (a música continua inteira); só alterna o zoom;
    3) se `alvo` > 0 (s), fica só com os pedaços de maior movimento/energia até chegar perto do alvo —
       tirando sempre pedaços inteiros (múltiplos de K batidas), para o ritmo da música não escorregar.
    Devolve (trechos [[de, ate], ...], info)."""
    info = dict(batida=False, bpm=0.0, confianca=0.0, batidas_por_corte=0)
    grade = None
    if usar_batida and wav:
        x, sr = None, 16000
        try:
            with wave.open(wav) as w:
                x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
                sr = w.getframerate()
        except Exception:
            x = None
        if x is not None:
            ts, bpm, conf = batidas(x, sr, de)
            info.update(bpm=round(bpm, 1), confianca=round(conf, 2))
            if conf >= 0.25 and len(ts) >= 8:
                per = 60.0 / bpm
                k = max(1, int(round(max_plano / per)))
                if k >= 3 and k % 2 == 1:
                    k += 1                       # grupos de batidas pares (compasso)
                # começa no grupo cujas batidas iniciais são mais fortes (aprox. o tempo forte)
                info.update(batida=True, batidas_por_corte=k)
                grade = [de] + [ts[i] for i in range(0, len(ts), k) if ts[i] - de >= minimo]   # nunca come o começo
    if grade is None:
        passo = max_plano
        grade = [de + i * passo for i in range(int((ate - de) / passo) + 1)]
    grade = [g for g in grade if de <= g < ate] + [ate]
    g_fps = 1.0 / fps
    snap = lambda v: round(round(v / g_fps) * g_fps, 4)
    pedacos = []
    for a_, b_ in zip(grade[:-1], grade[1:]):
        if b_ - a_ >= minimo:
            pedacos.append([snap(a_), snap(b_)])
        elif pedacos:
            pedacos[-1][1] = snap(b_)            # sobra curta: gruda no pedaço anterior
    if alvo and alvo > 0 and sum(b - a for a, b in pedacos) > alvo * 1.08:
        mov = movimento(video, de, ate)
        def media(a, b):
            v = [val for t, val in mov if a <= t < b]
            return sum(v) / len(v) if v else 0.0
        m = [media(a, b) for a, b in pedacos]
        ordem_m = sorted(m)
        ref = ordem_m[int(0.9 * (len(ordem_m) - 1))] or 1.0
        pontos = [min(1.0, v / ref) for v in m]
        n = max(1, int(round(alvo / (sum(b - a for a, b in pedacos) / len(pedacos)))))
        topo = sorted(range(len(pedacos)), key=lambda i: -pontos[i])[:n]
        pedacos = [pedacos[i] for i in sorted(topo)]
    return pedacos, info


def carregar_glossario():
    try:
        return json.load(open(os.path.join(SKILL, 'referencias', 'glossario.json'), encoding='utf-8'))
    except Exception:
        return {}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('video', nargs='?')
    ap.add_argument('--saida')
    ap.add_argument('--modelo', default='medium')
    ap.add_argument('--limiar-db', type=float, default=27.0)
    ap.add_argument('--zoom', type=float, default=1.12)
    ap.add_argument('--sem-zoom', action='store_true')
    ap.add_argument('--prompt', help='dica de vocabulário para o Whisper (pode ecoar no modelo small)')
    ap.add_argument('--de', type=float, default=0.0, help='início do trecho a analisar (s da mídia)')
    ap.add_argument('--ate', type=float, default=None, help='fim do trecho a analisar (s da mídia)')
    ap.add_argument('--modo', choices=['fala', 'sem-fala'], default='fala', help='fala: corta pela voz; sem-fala: corta por mudança de plano e ritmo')
    ap.add_argument('--max-plano', type=float, default=3.0, help='modo sem-fala: duração máxima de cada plano (s)')
    ap.add_argument('--alvo', type=float, default=0.0, help='modo sem-fala: duração final desejada (s); 0 = manter tudo')
    ap.add_argument('--sem-batida', action='store_true', help='modo sem-fala: não alinhar os cortes à música')
    ap.add_argument('--so-srt')
    a = ap.parse_args()
    glos = carregar_glossario()

    if a.so_srt:
        plano = json.load(open(a.so_srt, encoding='utf-8'))
        n = gerar_srt(plano, glos, os.path.join(os.path.dirname(a.so_srt), 'legendas.srt'))
        print('legendas.srt refeito com %d blocos' % n); return
    if not a.video:
        ap.error('informe o vídeo')
    video = os.path.abspath(os.path.expanduser(a.video))
    if not os.path.exists(video):
        sys.exit('arquivo não existe: ' + video)
    nome = os.path.splitext(os.path.basename(video))[0]
    saida = a.saida or os.path.join(HOME, 'Movies', 'JM Premiere', '%s-%s' % (nome, time.strftime('%Y%m%d-%H%M')))
    os.makedirs(saida, exist_ok=True)

    print('@@Lendo o vídeo…', file=sys.stderr, flush=True)
    info = sonda(video)
    if a.modo == 'sem-fala':
        print('@@Procurando as mudanças de plano…', file=sys.stderr, flush=True)
        fim_faixa = min(a.ate, info['duracao']) if a.ate else info['duracao']
        wav_sf = None
        if info['tem_audio'] and not a.sem_batida:
            print('@@Ouvindo o ritmo da música…', file=sys.stderr, flush=True)
            wav_sf = os.path.join(saida, 'audio16k.wav')
            extrair_audio(video, wav_sf, a.de, fim_faixa)
        brutos, info_sf = trechos_sem_fala(video, a.de, fim_faixa, info['fps'], a.max_plano, wav=wav_sf, usar_batida=not a.sem_batida, alvo=a.alvo)
        print('@@Decidindo o ritmo dos cortes…', file=sys.stderr, flush=True)
        zooms = [1.0, a.zoom]
        trechos, pos = [], 0.0
        for i, (de_, ate_) in enumerate(brutos):
            trechos.append(dict(de=de_, ate=ate_, zoom=1.0 if a.sem_zoom else zooms[i % 2], tl_inicio=round(pos, 4)))
            pos += ate_ - de_
        plano = dict(video=video, modo='sem-fala', info=info, duracao_original=round(fim_faixa - a.de, 2), faixa=[a.de, fim_faixa],
                     duracao_final=round(pos, 2), trechos=trechos, removidos=[], palavras=[], ritmo=info_sf)
        json.dump(plano, open(os.path.join(saida, 'plano.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(json.dumps(dict(saida=saida, modo='sem-fala', ritmo=info_sf, trechos=len(trechos), duracao_original=plano['duracao_original'],
                              duracao_final=plano['duracao_final'], removidos=0, blocos_de_legenda=0,
                              largura_altura=[info['largura'], info['altura']], fps=round(info['fps'], 3)), ensure_ascii=False))
        return
    if not info['tem_audio']:
        sys.exit('o vídeo não tem áudio: sem fala para analisar')
    wav = os.path.join(saida, 'voz16k.wav')
    print('@@Procurando as falas…', file=sys.stderr, flush=True)
    fim_faixa = min(a.ate, info['duracao']) if a.ate else info['duracao']
    x, sr = extrair_audio(video, wav, a.de, fim_faixa)
    regs, pico = regioes_de_voz(x, sr, a.limiar_db)
    regs = [[r[0] + a.de, r[1] + a.de] for r in regs]  # tempos sempre na linha do tempo da mídia
    print('@@Transcrevendo a fala (leva cerca de 1x a duração do vídeo)…', file=sys.stderr, flush=True)
    pal = transcrever(wav, a.modelo, glos, a.prompt)
    print('@@Decidindo os cortes…', file=sys.stderr, flush=True)
    for p in pal:
        p['t0'] = round(p['t0'] + a.de, 3); p['t1'] = round(p['t1'] + a.de, 3)
    pal = [p for p in pal if p['t1'] > p['t0'] and any(r[0] - 0.1 <= (p['t0'] + p['t1']) / 2 <= r[1] + 0.1 for r in regs)]  # tira alucinação fora da voz
    rem, rel = marcar_remocoes(pal)
    regs2 = subtrair(regs, rem)
    mantidas = [p for p in pal if not any(ra <= p['t0'] and p['t1'] <= rb + 0.01 for ra, rb in rem)]
    # trecho sem nenhuma palavra (clique, tosse, barulho) não entra
    regs2 = [r for r in regs2 if any(r[0] - 0.05 <= (p['t0'] + p['t1']) / 2 <= r[1] + 0.05 for p in mantidas)]
    trechos_brutos = montar_trechos(regs2, fim_faixa, info['fps'])

    trechos, pos = [], 0.0
    zooms = [1.0, a.zoom]
    for i, (de, ate) in enumerate(trechos_brutos):
        z = 1.0 if a.sem_zoom else zooms[i % 2]
        trechos.append(dict(de=de, ate=ate, zoom=z, tl_inicio=round(pos, 4)))
        pos += ate - de
    for p in pal:
        p['tl0'] = tempo_timeline(trechos, p['t0'])
        p['tl1'] = tempo_timeline(trechos, p['t1']) if p['tl0'] is not None else None
        if p['tl0'] is not None and (p['tl1'] is None or p['tl1'] < p['tl0']):
            p['tl1'] = p['tl0'] + (p['t1'] - p['t0'])  # palavra termina fora do trecho: mantém a duração
        p['removida'] = any(ra <= p['t0'] and p['t1'] <= rb + 0.01 for ra, rb in rem) or (p['tl0'] is None)
        if p['removida']:
            p['tl0'] = p['tl1'] = None

    plano = dict(video=video, info=info, pico_db=round(pico, 1), limiar_db=a.limiar_db,
                 duracao_original=round(fim_faixa - a.de, 2), faixa=[a.de, fim_faixa], duracao_final=round(pos, 2),
                 trechos=trechos, removidos=[dict(tipo=t, texto=w, em=round(s, 2)) for t, w, s in rel],
                 palavras=pal)
    json.dump(plano, open(os.path.join(saida, 'plano.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    with open(os.path.join(saida, 'transcricao.txt'), 'w', encoding='utf-8') as f:
        for tr in trechos:
            ws = [p for p in pal if not p['removida'] and tr['de'] - .001 <= p['t0'] <= tr['ate']]
            f.write('[%6.2f – %6.2f | tl %6.2f] %s\n' % (tr['de'], tr['ate'], tr['tl_inicio'], ' '.join(p['w'] for p in ws)))
        f.write('\nREMOVIDOS:\n' + '\n'.join('  %-9s %6.2fs  %s' % (t, s, w) for t, w, s in rel) + '\n')
    nb = gerar_srt(plano, glos, os.path.join(saida, 'legendas.srt'))
    print(json.dumps(dict(saida=saida, trechos=len(trechos), duracao_original=plano['duracao_original'],
                          duracao_final=plano['duracao_final'], removidos=len(rel), blocos_de_legenda=nb,
                          largura_altura=[info['largura'], info['altura']], fps=round(info['fps'], 3)),
                     ensure_ascii=False))


if __name__ == '__main__':
    main()

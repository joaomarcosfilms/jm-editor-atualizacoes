// JM Ponte — biblioteca ExtendScript que roda DENTRO do Premiere Pro.
// ExtendScript é JavaScript antigo (ES3): sem let/const, sem =>, sem JSON nativo.
// Tudo fica em $.global.JM. Quem chama é o servidor (main.js) via JM_run(código).

$.global.JM = $.global.JM || {};
var JM = $.global.JM;

JM.TICKS = 254016000000; // ticks por segundo no Premiere

// ---------- JSON (o ExtendScript não tem) ----------
JM.q = function (s) {
    var out = '"', i, c, code;
    s = String(s);
    for (i = 0; i < s.length; i++) {
        c = s.charAt(i); code = s.charCodeAt(i);
        if (c === '"') out += '\\"';
        else if (c === '\\') out += '\\\\';
        else if (c === '\n') out += '\\n';
        else if (c === '\r') out += '\\r';
        else if (c === '\t') out += '\\t';
        else if (code < 32) out += '\\u' + ('0000' + code.toString(16)).slice(-4);
        else out += c;
    }
    return out + '"';
};
JM.json = function (v, d) {
    d = d || 0;
    if (d > 7) return '"…"';
    var t = typeof v, i, k, parts, x;
    if (v === null || v === undefined) return 'null';
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return String(v);
    if (t === 'string') return JM.q(v);
    if (t === 'function') return 'null';
    if (v instanceof Array) {
        parts = [];
        for (i = 0; i < v.length; i++) parts.push(JM.json(v[i], d + 1));
        return '[' + parts.join(',') + ']';
    }
    parts = [];
    try {
        for (k in v) {
            try { x = v[k]; } catch (e1) { continue; }
            if (typeof x === 'function') continue;
            parts.push(JM.q(k) + ':' + JM.json(x, d + 1));
        }
    } catch (e2) { return JM.q(String(v)); }
    if (!parts.length) return JM.q(String(v));
    return '{' + parts.join(',') + '}';
};

// Executa código e devolve sempre um JSON {"ok":..., "v":...} ou {"ok":false,"erro":...}
function JM_run(code) {
    try {
        var r = eval(code);
        return '{"ok":true,"v":' + JM.json(r) + '}';
    } catch (e) {
        return '{"ok":false,"erro":' + JM.q(String(e.message || e)) + ',"linha":' + (e.line || 0) + '}';
    }
}

// ---------- utilidades ----------
JM.T = function (sec) { var t = new Time(); t.seconds = sec; return t; };
JM.seg = function (t) { // Time (.seconds) ou string de ticks (ex.: sequence.end)
    try { if (t.seconds !== undefined) return t.seconds; } catch (e) { /* segue */ }
    var n = Number(t);
    return n > 100000 ? n / JM.TICKS : n;
};
JM.lista = function (colecao) { // coleção do Premiere -> array
    var a = [], i, n = 0;
    try { n = colecao.numItems !== undefined ? colecao.numItems : colecao.length; } catch (e) { return a; }
    for (i = 0; i < n; i++) a.push(colecao[i]);
    return a;
};
JM.arred = function (n, casas) { var f = Math.pow(10, casas || 3); return Math.round(n * f) / f; };

// ---------- estado do Premiere ----------
JM.info = function () {
    var p = app.project, s = null, r = { versao: app.version };
    if (!p) { r.projeto = null; return r; }
    r.projeto = p.name; r.caminho = p.path;
    try { s = p.activeSequence; } catch (e) { s = null; }
    r.sequenciaAtiva = s ? s.name : null;
    if (s) {
        r.larguraAltura = [s.frameSizeHorizontal, s.frameSizeVertical];
        try { r.duracao = JM.arred(JM.seg(s.end), 2); } catch (e3) { r.duracao = null; }
    }
    r.sequencias = [];
    var ss = JM.lista(p.sequences), i;
    for (i = 0; i < ss.length; i++) r.sequencias.push(ss[i].name);
    return r;
};

// Árvore do painel Projeto: [{nome, tipo, nodeId, midia}]
JM.arvore = function (bin, prof) {
    bin = bin || app.project.rootItem; prof = prof || 0;
    var r = [], f = JM.lista(bin.children), i, it, o;
    for (i = 0; i < f.length; i++) {
        it = f[i]; o = { nome: it.name, tipo: it.type, nodeId: it.nodeId };
        try { if (it.type === 1) o.midia = it.getMediaPath(); } catch (e) { /* sem mídia */ }
        if (it.type === 2 && prof < 4) o.filhos = JM.arvore(it, prof + 1);
        r.push(o);
    }
    return r;
};

// Procura item do projeto por caminho da mídia, nodeId ou nome (nessa ordem)
JM.achar = function (ref, bin) {
    bin = bin || app.project.rootItem;
    var f = JM.lista(bin.children), i, it, r, mp;
    for (i = 0; i < f.length; i++) {
        it = f[i];
        if (it.type === 2) { r = JM.achar(ref, it); if (r) return r; continue; }
        mp = '';
        try { mp = it.getMediaPath(); } catch (e) { mp = ''; }
        if (it.nodeId === ref || mp === ref || it.name === ref) return it;
    }
    return null;
};

JM.bin = function (nome) {
    var f = JM.lista(app.project.rootItem.children), i;
    for (i = 0; i < f.length; i++) if (f[i].type === 2 && f[i].name === nome) return f[i];
    return app.project.rootItem.createBin(nome);
};

// Importa arquivos (nunca altera o original). Devolve os itens achados.
JM.importar = function (caminhos, nomeBin) {
    var alvo = JM.bin(nomeBin || 'JM Edições'), i, ok, out = [], it;
    if (typeof caminhos === 'string') caminhos = [caminhos];
    for (i = 0; i < caminhos.length; i++) {
        if (!File(caminhos[i]).exists) throw new Error('arquivo não existe: ' + caminhos[i]);
    }
    ok = app.project.importFiles(caminhos, true, alvo, false);
    for (i = 0; i < caminhos.length; i++) {
        it = JM.achar(caminhos[i]);
        out.push(it ? { nome: it.name, nodeId: it.nodeId } : { nome: null, caminho: caminhos[i] });
    }
    return { importou: ok, itens: out };
};

JM.sequenciaPorNome = function (nome) {
    var ss = JM.lista(app.project.sequences), i, r = null;
    for (i = 0; i < ss.length; i++) if (ss[i].name === nome) r = ss[i]; // a última com esse nome
    return r;
};

// Cria uma sequência NOVA com as configurações do clipe (nunca mexe nas existentes) e a abre.
JM.novaSequencia = function (nome, ref) {
    var it = JM.achar(ref);
    if (!it) throw new Error('item não encontrado: ' + ref);
    var bin = JM.bin('JM Edições');
    app.project.createNewSequenceFromClips(nome, [it], bin);
    var s = JM.sequenciaPorNome(nome);
    if (!s) throw new Error('a sequência não apareceu: ' + nome);
    app.project.openSequence(s.sequenceID);
    app.project.activeSequence = s;
    return { nome: s.name, id: s.sequenceID, larguraAltura: [s.frameSizeHorizontal, s.frameSizeVertical] };
};

JM.ativa = function () {
    var s = app.project.activeSequence;
    if (!s) throw new Error('nenhuma sequência ativa');
    return s;
};

JM.limparTrilhas = function (s) {
    var tr, i, j, cl;
    s = s || JM.ativa();
    tr = JM.lista(s.videoTracks).concat(JM.lista(s.audioTracks));
    for (i = 0; i < tr.length; i++) {
        cl = JM.lista(tr[i].clips);
        for (j = cl.length - 1; j >= 0; j--) cl[j].remove(false, false);
    }
};

// Marca entrada/saída no item do projeto (segundos). Confere de volta; tenta ticks se preciso.
JM.marcar = function (it, a, b) {
    var ok = false, tent = 0, ia, ib;
    function ler() { try { ia = JM.seg(it.getInPoint()); ib = JM.seg(it.getOutPoint()); } catch (e) { ia = -1; ib = -1; } }
    function perto(x, y) { return Math.abs(x - y) < 0.05; }
    it.setInPoint(a, 4); it.setOutPoint(b, 4); ler();
    if (perto(ia, a) && perto(ib, b)) return true;
    it.setInPoint(String(Math.round(a * JM.TICKS)), 4); it.setOutPoint(String(Math.round(b * JM.TICKS)), 4); ler();
    if (perto(ia, a) && perto(ib, b)) return true;
    throw new Error('não consegui marcar entrada/saída (pedido ' + a + '–' + b + ', ficou ' + ia + '–' + ib + ')');
};

// Monta a edição: recebe a lista de trechos [{de, ate, zoom}] em segundos da mídia de origem.
// Cria os cortes secos um depois do outro na V1/A1 da sequência ativa.
JM.montar = function (ref, trechos, opcoes) {
    opcoes = opcoes || {};
    var it = JM.achar(ref), s = JM.ativa(), pos = 0, i, t, v, rel = [];
    if (!it) throw new Error('item não encontrado: ' + ref);
    var inicial = null, fimInicial = null;
    try { inicial = JM.seg(it.getInPoint()); fimInicial = JM.seg(it.getOutPoint()); } catch (e0) { /* ok */ }
    JM.limparTrilhas(s);
    v = s.videoTracks[0];
    for (i = 0; i < trechos.length; i++) {
        t = trechos[i];
        JM.marcar(it, t.de, t.ate);
        v.overwriteClip(it, JM.T(pos));
        rel.push({ n: i, origem: [t.de, t.ate], timeline: [JM.arred(pos, 3), JM.arred(pos + (t.ate - t.de), 3)] });
        pos += (t.ate - t.de);
    }
    // devolve entrada/saída original do item no painel Projeto
    try { if (inicial !== null) { it.setInPoint(inicial, 4); it.setOutPoint(fimInicial, 4); } } catch (e1) { /* ok */ }
    return { trechos: rel, duracao: JM.arred(pos, 3) };
};

// Confere o que realmente ficou na timeline: [{trilha, i, inicio, fim, entrada, saida, nome}]
JM.resumo = function (s) {
    s = s || JM.ativa();
    var r = [], tr, i, j, cl, c, nomeTrilha;
    var grupos = [['V', JM.lista(s.videoTracks)], ['A', JM.lista(s.audioTracks)]], g;
    for (g = 0; g < grupos.length; g++) {
        tr = grupos[g][1];
        for (i = 0; i < tr.length; i++) {
            cl = JM.lista(tr[i].clips);
            for (j = 0; j < cl.length; j++) {
                c = cl[j];
                r.push({ trilha: grupos[g][0] + (i + 1), i: j, nome: c.name,
                    inicio: JM.arred(JM.seg(c.start), 3), fim: JM.arred(JM.seg(c.end), 3),
                    entrada: JM.arred(JM.seg(c.inPoint), 3), saida: JM.arred(JM.seg(c.outPoint), 3) });
            }
        }
    }
    return r;
};

// ---------- efeitos e propriedades ----------
// Lista os componentes (efeitos) de um clipe com suas propriedades — para descobrir nomes.
JM.componentes = function (trilha, indice, video) {
    var s = JM.ativa(), tr = (video === false ? s.audioTracks : s.videoTracks)[trilha || 0];
    var c = tr.clips[indice || 0], cs = JM.lista(c.components), r = [], i, j, ps, p, o;
    for (i = 0; i < cs.length; i++) {
        o = { i: i, nome: cs[i].displayName, match: (cs[i].matchName || ''), props: [] };
        ps = JM.lista(cs[i].properties);
        for (j = 0; j < ps.length; j++) {
            p = ps[j]; var val = null;
            try { val = p.getValue(); } catch (e) { val = '?'; }
            o.props.push({ i: j, nome: p.displayName, valor: (typeof val === 'object' && val !== null) ? JM.json(val) : val });
        }
        r.push(o);
    }
    return r;
};

JM.achaComp = function (clipe, nomes) { // nomes: lista de displayName/matchName aceitos
    var cs = JM.lista(clipe.components), i, k;
    for (i = 0; i < cs.length; i++)
        for (k = 0; k < nomes.length; k++)
            if (cs[i].displayName === nomes[k] || cs[i].matchName === nomes[k]) return cs[i];
    return null;
};
JM.achaProp = function (comp, nomes) {
    var ps = JM.lista(comp.properties), i, k;
    for (i = 0; i < ps.length; i++)
        for (k = 0; k < nomes.length; k++)
            if (ps[i].displayName === nomes[k] || ps[i].matchName === nomes[k]) return ps[i];
    return null;
};

// Zoom (escala %) num clipe de vídeo. Premiere em português: "Movimento"/"Escala".
JM.escala = function (trilha, indice, porcento) {
    var s = JM.ativa(), c = s.videoTracks[trilha || 0].clips[indice];
    var m = JM.achaComp(c, ['AE.ADBE Motion', 'Motion', 'Movimento']);
    if (!m) throw new Error('componente Movimento não achado');
    var p = JM.achaProp(m, ['ADBE Scale', 'Scale', 'Escala']);
    if (!p) throw new Error('propriedade Escala não achada');
    p.setValue(porcento, true);
    return porcento;
};

// Posição normalizada (0–1) no clipe de vídeo: [x, y]
JM.posicao = function (trilha, indice, x, y) {
    var s = JM.ativa(), c = s.videoTracks[trilha || 0].clips[indice];
    var m = JM.achaComp(c, ['AE.ADBE Motion', 'Motion', 'Movimento']);
    var p = JM.achaProp(m, ['ADBE Position', 'Position', 'Posição']);
    if (!p) throw new Error('propriedade Posição não achada');
    p.setValue([x, y], true);
    return [x, y];
};

// Aplica um efeito de vídeo pelo nome (QE). Ex.: 'Lumetri Color' / 'Cor Lumetri'
JM.efeito = function (trilha, indice, nomes) {
    app.enableQE();
    var q = qe.project.getActiveSequence(), qt = q.getVideoTrackAt(trilha || 0), qc = qt.getItemAt(indice);
    var lista = (typeof nomes === 'string') ? [nomes] : nomes, i, fx = null, usado = null;
    for (i = 0; i < lista.length && !fx; i++) {
        try { fx = qe.project.getVideoEffectByName(lista[i]); usado = lista[i]; } catch (e) { fx = null; }
    }
    if (!fx) throw new Error('efeito não achado: ' + lista.join(' | '));
    qc.addVideoEffect(fx);
    return usado;
};

// ---------- legendas, marcadores, saída ----------
JM.legendasSRT = function (caminho, inicioSeg) {
    var s = JM.ativa(), imp = JM.importar([caminho], 'JM Edições'), it = JM.achar(caminho);
    if (!it) throw new Error('SRT importado mas não achado no projeto');
    var fmt = (typeof Sequence !== 'undefined' && Sequence.CAPTION_FORMAT_SUBTITLE !== undefined) ? Sequence.CAPTION_FORMAT_SUBTITLE : 0;
    var r = s.createCaptionTrack(it, inicioSeg || 0, fmt);
    return { importou: imp.importou, criou: r };
};

JM.marcador = function (seg, nome, cor) {
    var s = JM.ativa(), m = s.markers.createMarker(seg);
    m.name = nome || '';
    if (cor !== undefined) { try { m.setColorByIndex(cor); } catch (e) { /* ok */ } }
    return true;
};

JM.quadro = function (seg, destinoPNG) { // quadro da sequência para conferir visualmente
    var s = JM.ativa();
    return s.exportFramePNG(JM.T(seg), destinoPNG);
};

// 0 = sequência inteira, 1 = entrada/saída, 2 = área de trabalho
JM.exportar = function (saida, preset, area) {
    var s = JM.ativa();
    if (!File(preset).exists) throw new Error('preset não existe: ' + preset);
    return s.exportAsMediaDirect(saida, preset, area === undefined ? 0 : area);
};

JM.salvar = function () { app.project.save(); return app.project.path; };

// ---------- botão "Editar sozinho" (painel) ----------
// Vídeos selecionados no painel Projeto (ou clipe selecionado na timeline): [{nome,nodeId,caminho}]
JM.selecionado = function () {
    var out = [], sel = [], i, it, c, s;
    try { sel = JM.lista(app.project.getSelection()); } catch (e1) { sel = []; }
    for (i = 0; i < sel.length; i++) {
        it = sel[i];
        if (it.type === 1) {
            try { out.push({ nome: it.name, nodeId: it.nodeId, caminho: it.getMediaPath() }); } catch (e2) { /* sem mídia */ }
        }
    }
    if (!out.length) {
        try {
            s = app.project.activeSequence;
            sel = JM.lista(s.getSelection());
            for (i = 0; i < sel.length; i++) {
                c = sel[i];
                try { out.push({ nome: c.name, nodeId: c.projectItem.nodeId, caminho: c.projectItem.getMediaPath() }); } catch (e3) { /* ok */ }
            }
        } catch (e4) { /* sem sequência */ }
    }
    return out;
};

JM.escolherArquivo = function () {
    var f = File.openDialog('Escolha o vídeo para editar');
    return f ? f.fsName : null;
};

// zooms[i] = fator do clipe i da V1 (1 = sem zoom). Só mexe nos que têm zoom.
JM.aplicarZooms = function (zooms) {
    var i, n = 0;
    for (i = 0; i < zooms.length; i++) {
        if (zooms[i] && Math.abs(zooms[i] - 1) > 0.001) { JM.escala(0, i, Math.round(zooms[i] * 100)); n++; }
    }
    return n;
};

// ---------- editar O QUE JÁ ESTÁ NA TIMELINE (plugin) ----------
// Estado da sequência ativa: clipes da V1 com a mídia de origem, entrada/saída usadas e se estão selecionados.
JM.timeline = function () {
    var s = null, r = { sequencia: null, clipes: [], temSelecao: false };
    try { s = app.project.activeSequence; } catch (e0) { s = null; }
    if (!s) return r;
    r.sequencia = s.name;
    r.larguraAltura = [s.frameSizeHorizontal, s.frameSizeVertical];
    var cl = JM.lista(s.videoTracks[0].clips), sel = [], i, k, c, o, x;
    try { sel = JM.lista(s.getSelection()); } catch (e1) { sel = []; }
    for (i = 0; i < cl.length; i++) {
        c = cl[i];
        o = { indice: i, nome: c.name, inicio: JM.arred(JM.seg(c.start), 3), fim: JM.arred(JM.seg(c.end), 3),
              entrada: JM.arred(JM.seg(c.inPoint), 3), saida: JM.arred(JM.seg(c.outPoint), 3), caminho: null, selecionado: false };
        try { o.caminho = c.projectItem.getMediaPath(); } catch (e2) { o.caminho = null; }
        try {
            for (k = 0; k < sel.length; k++) {
                x = sel[k];
                if (x.projectItem && x.projectItem.nodeId === c.projectItem.nodeId && Math.abs(JM.seg(x.start) - JM.seg(c.start)) < 0.05) o.selecionado = true;
            }
        } catch (e3) { /* sem seleção */ }
        if (o.selecionado) r.temSelecao = true;
        r.clipes.push(o);
    }
    try { r.duracao = JM.arred(JM.seg(s.end), 2); } catch (e4) { r.duracao = null; }
    try { r.fps = JM.arred(JM.TICKS / Number(s.timebase), 3); } catch (e5) { r.fps = null; }
    return r;
};

// Legenda criativa: coloca o vídeo transparente (gerado pelo motor) numa trilha de vídeo LIVRE acima da V1.
// Só remove legendas que o próprio JM Editor criou antes (arquivos "JM-legenda-…"); nunca mexe em outros clipes.
JM.legendaNaTimeline = function (caminho, escalaPct) {
    var s = JM.ativa(), t, i, cl, nome, removidos = 0, trilha = -1, item, achou = -1, c;
    if (!s) throw new Error('nenhuma sequência ativa');
    for (t = 1; t < s.videoTracks.numTracks; t++) {
        cl = s.videoTracks[t].clips;
        for (i = cl.numItems - 1; i >= 0; i--) {
            nome = '';
            try { nome = cl[i].projectItem.name; } catch (e0) { nome = ''; }
            if (/^JM-legenda-/.test(nome)) { cl[i].remove(false, false); removidos++; }
        }
    }
    for (t = 1; t < s.videoTracks.numTracks; t++) {
        if (s.videoTracks[t].clips.numItems === 0) { trilha = t; break; }
    }
    if (trilha < 0) throw new Error('não há trilha de vídeo livre acima da V1: libere a V2 ou a V3 e tente de novo');
    JM.importar([caminho], 'JM Edições');
    item = JM.achar(caminho);
    if (!item) throw new Error('não consegui importar o vídeo da legenda');
    s.videoTracks[trilha].overwriteClip(item, JM.T(0));
    cl = s.videoTracks[trilha].clips;
    for (i = 0; i < cl.numItems; i++) { c = cl[i]; if (Math.abs(JM.seg(c.start)) < 0.05) { achou = i; break; } }
    if (achou < 0) throw new Error('a legenda não entrou na trilha V' + (trilha + 1));
    JM.escala(trilha, achou, escalaPct || 100);
    return { trilha: 'V' + (trilha + 1), indice: achou, escala: escalaPct || 100, removidas: removidos,
             inicio: JM.arred(JM.seg(cl[achou].start), 3), fim: JM.arred(JM.seg(cl[achou].end), 3) };
};

// Cópia de segurança da sequência ativa (clone) — o original continua ativo.
JM.copiaSeguranca = function (rotulo) {
    var s = JM.ativa(), antes = {}, ss = JM.lista(app.project.sequences), i, novo = null;
    for (i = 0; i < ss.length; i++) antes[ss[i].sequenceID] = true;
    s.clone();
    ss = JM.lista(app.project.sequences);
    for (i = 0; i < ss.length; i++) if (!antes[ss[i].sequenceID]) novo = ss[i];
    if (!novo) throw new Error('o Premiere não criou a cópia da sequência');
    novo.name = rotulo;
    try { app.project.openSequence(s.sequenceID); } catch (e) { /* já está ativa */ }
    return { copia: novo.name };
};

// Multiplica a escala atual do clipe (fator 1.12 = +12%).
JM.escalaRel = function (c, fator) {
    var m = JM.achaComp(c, ['AE.ADBE Motion', 'Motion', 'Movimento']);
    if (!m) throw new Error('componente Movimento não achado');
    var p = JM.achaProp(m, ['ADBE Scale', 'Scale', 'Escala']);
    if (!p) throw new Error('propriedade Escala não achada');
    var base = p.getValue();
    var novo = Math.round(base * fator * 100) / 100;
    p.setValue(novo, true);
    return novo;
};

// pedidos = [{indice, trechos:[{de, ate, zoom}]}]  (indice = posição do clipe na V1; trechos em segundos da MÍDIA)
// Troca cada clipe pedido pelos seus trechos em corte seco. Sem ripple: o resto da timeline não anda.
// juntar = true: os trechos de todos os clipes ficam colados, um depois do outro, a partir do primeiro clipe.
JM.editarNaTimeline = function (pedidos, juntar) {
    var s = JM.ativa(), v = s.videoTracks[0], cl = JM.lista(v.clips), alvos = [], i, j, k, p, c, t, a0, trk, acl;
    if (!pedidos || !pedidos.length) throw new Error('nada para editar');
    for (i = 0; i < pedidos.length; i++) {
        p = pedidos[i]; c = cl[p.indice];
        if (!c) throw new Error('clipe ' + p.indice + ' não existe mais na V1');
        alvos.push({ clipe: c, item: c.projectItem, ini: JM.seg(c.start), fim: JM.seg(c.end), nodeId: c.projectItem.nodeId, trechos: p.trechos });
    }
    // 1) tira o áudio ligado a cada clipe (mesma mídia, mesmo início) e depois o vídeo
    var aud = JM.lista(s.audioTracks), tirar = [];
    for (j = 0; j < aud.length; j++) {
        acl = JM.lista(aud[j].clips);
        for (k = 0; k < acl.length; k++) {
            for (i = 0; i < alvos.length; i++) {
                try {
                    if (acl[k].projectItem.nodeId === alvos[i].nodeId && Math.abs(JM.seg(acl[k].start) - alvos[i].ini) < 0.05) tirar.push(acl[k]);
                } catch (e) { /* sem projectItem */ }
            }
        }
    }
    for (k = 0; k < tirar.length; k++) tirar[k].remove(false, false);
    for (i = 0; i < alvos.length; i++) alvos[i].clipe.remove(false, false);
    // 2) coloca os trechos
    var pos = alvos[0].ini, colocados = [], inOrig, outOrig;
    for (i = 0; i < alvos.length; i++) {
        a0 = alvos[i];
        if (!juntar) pos = a0.ini;
        inOrig = null; outOrig = null;
        try { inOrig = JM.seg(a0.item.getInPoint()); outOrig = JM.seg(a0.item.getOutPoint()); } catch (e1) { /* ok */ }
        for (k = 0; k < a0.trechos.length; k++) {
            t = a0.trechos[k];
            JM.marcar(a0.item, t.de, t.ate);
            v.overwriteClip(a0.item, JM.T(pos));
            colocados.push({ inicio: pos, zoom: t.zoom || 1 });
            pos += (t.ate - t.de);
        }
        try { if (inOrig !== null) { a0.item.setInPoint(inOrig, 4); a0.item.setOutPoint(outOrig, 4); } } catch (e2) { /* ok */ }
    }
    // 3) zoom alternado nos clipes novos
    var novos = JM.lista(v.clips), nz = 0;
    for (i = 0; i < colocados.length; i++) {
        if (Math.abs(colocados[i].zoom - 1) < 0.001) continue;
        for (k = 0; k < novos.length; k++) {
            if (Math.abs(JM.seg(novos[k].start) - colocados[i].inicio) < 0.05) { JM.escalaRel(novos[k], colocados[i].zoom); nz++; break; }
        }
    }
    return { colocados: colocados.length, comZoom: nz, fim: JM.arred(pos, 3) };
};

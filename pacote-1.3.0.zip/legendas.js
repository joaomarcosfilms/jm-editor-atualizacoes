/* JM Editor — aba Legendas (legendas criativas).
 * Fluxo: lê a timeline → motor Python (Whisper + Pillow) gera um vídeo transparente com as legendas desenhadas
 * → coloca numa trilha de vídeo livre acima da V1 (JM.legendaNaTimeline). Não mexe nos cortes nem no áudio. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var P = window.JMPainel;
  if (!P || !$('leg-criar')) return;
  var req = (typeof require !== 'undefined') ? require : (window.cep_node && window.cep_node.require);
  var cp = req('child_process'), fs = req('fs'), path = req('path'), os = req('os');
  var MOTOR = path.join(P.raiz, 'motor', 'scripts', 'legendas.py');

  var COR_PADRAO = { impacto: '#ffc400', karaoke: '#ffc400', elegante: '#e2ba62', tarja: '#ffc400' };
  var NOMES = { impacto: 'Impacto', karaoke: 'Karaokê', elegante: 'Elegante', tarja: 'Tarja' };
  var ocupado = false, cancelado = false, aplicando = false, proc = null, corMexida = false;

  function estilo() { var r = document.querySelector('input[name="leg-estilo"]:checked'); return r ? r.value : 'impacto'; }
  function fase(t) { $('leg-fase').textContent = t; }
  function pintaCor() { $('aba-legendas').style.setProperty('--leg-cor', $('leg-cor').value); }

  // ---------- abas ----------
  function aba(qual) {
    var leg = qual === 'legendas';
    $('aba-editar').style.display = leg ? 'none' : 'block';
    $('aba-legendas').style.display = leg ? 'block' : 'none';
    $('aba-b-editar').className = leg ? '' : 'on';
    $('aba-b-legendas').className = leg ? 'on' : '';
    try { window.localStorage.setItem('jm-aba', qual); } catch (e) {}
    atualizar();
  }
  $('aba-b-editar').addEventListener('click', function () { aba('editar'); });
  $('aba-b-legendas').addEventListener('click', function () { aba('legendas'); });

  // ---------- estado do botão ----------
  function atualizar() {
    var al = P.alvos(), tl = P.getTl();
    var info = !tl || !tl.sequencia ? 'Abra uma sequência com o vídeo na timeline.'
      : !al.length ? 'Nenhum clipe com mídia para legendar.'
      : (tl.temSelecao ? 'Vai legendar só o que está selecionado (' + al.length + ').' : 'Vai legendar tudo o que está na V1 (' + al.length + ').');
    $('leg-alvoinfo').textContent = info;
    if (!ocupado) $('leg-criar').disabled = !al.length || P.ocupado();
  }

  function trabalhando(on) {
    ocupado = on; P.bloquear(on);
    $('leg-barra').className = 'barra' + (on ? ' on' : '');
    $('leg-criar').className = on ? 'trabalhando' : '';
    $('leg-criar-txt').textContent = on ? 'Criando…' : 'Criar legendas';
    $('leg-cancelar').className = on ? 'on' : ''; $('leg-cancelar').disabled = false; $('leg-cancelar').textContent = 'Cancelar';
    if (on) { cancelado = false; aplicando = false; $('leg-criar').disabled = true; }
    else atualizar();
  }
  function checar() { if (cancelado) { var e = new Error('Cancelado. Nada foi alterado na timeline.'); e.cancelado = true; throw e; } }
  function cancelar() {
    if (!ocupado || cancelado) return;
    if (aplicando) { P.log('Já está colocando a legenda: não dá para cancelar agora. Use ⌘Z para desfazer.', 'erro'); return; }
    cancelado = true; $('leg-cancelar').disabled = true; $('leg-cancelar').textContent = 'Cancelando…'; fase('Cancelando…');
    if (proc) { try { process.kill(-proc.pid, 'SIGTERM'); } catch (e) { try { proc.kill('SIGTERM'); } catch (e2) {} } }
  }

  // ---------- motor ----------
  function rodar(pedidoArq) {
    return new Promise(function (ok, falha) {
      var env = Object.assign({}, process.env, { PATH: path.join(os.homedir(), '.jm-ponte', 'bin') + ':/opt/homebrew/bin:/usr/local/bin:' + (process.env.PATH || '') });
      var p = cp.spawn(P.python, [MOTOR, pedidoArq], { env: env, detached: true });
      proc = p;
      var out = '', err = '';
      p.stdout.on('data', function (d) { out += d; });
      p.stderr.on('data', function (d) {
        err += d;
        String(d).split('\n').forEach(function (l) { if (l.indexOf('@@') === 0) { var t = l.slice(2).trim(); fase(t); if (t.indexOf('%') < 0) P.log('· ' + t); } });
      });
      p.on('error', falha);
      p.on('close', function (c) {
        proc = null;
        if (cancelado) { var ce = new Error('Cancelado. Nada foi alterado na timeline.'); ce.cancelado = true; return falha(ce); }
        if (c === 0) return ok(out);
        if (c === 3) { var se = new Error('Não achei fala nos clipes, então não há o que legendar. Nada foi alterado.'); se.suave = true; return falha(se); }
        if (c === 4 || err.indexOf('FALTA_PILLOW') >= 0) return falha(new Error('falta o componente de desenho das legendas (Pillow). Rode o Instalar.command mais novo uma vez e tente de novo.'));
        falha(new Error('o motor de legendas falhou (código ' + c + '): ' + err.split('\n').filter(function (l) { return l && l.indexOf('@@') !== 0 && l.indexOf('Warning') < 0 && l.indexOf('mel_spec') < 0; }).slice(-4).join(' | ')));
      });
    });
  }

  async function criar() {
    if (ocupado || P.ocupado()) return;
    await P.lerTimeline(true);
    var al = P.alvos(), tl = P.getTl();
    if (!al.length || !tl) return;
    trabalhando(true); $('leg-resultado').style.display = 'none'; $('leg-avisos').innerHTML = '';
    var t0 = Date.now(), est = estilo();
    try {
      if (!fs.existsSync(P.python)) throw new Error('Python não encontrado em ' + P.python + '. Rode o Instalar.command de novo.');
      if (!fs.existsSync(MOTOR)) throw new Error('motor de legendas ausente. Rode o Instalar.command (ou scripts/instalar-ponte.sh) de novo.');
      for (var i = 0; i < al.length; i++) if (!fs.existsSync(al[i].caminho)) throw new Error('mídia offline: ' + al[i].caminho);
      var dur = tl.duracao || Math.max.apply(null, tl.clipes.map(function (c) { return c.fim; }));
      var pasta = path.join(os.homedir(), 'Movies', 'JM Premiere', 'legendas-' + new Date().toISOString().slice(0, 19).replace(/[-:T]/g, ''));
      fs.mkdirSync(pasta, { recursive: true });
      var pedido = {
        clips: al.map(function (c) { return { arquivo: c.caminho, entrada: c.entrada, saida: c.saida, inicio: c.inicio, fim: c.fim }; }),
        largura: tl.larguraAltura[0], altura: tl.larguraAltura[1], fps: tl.fps || 0, duracao: dur,
        estilo: est, cor: $('leg-cor').value, posicao: $('leg-pos').value, tamanho: $('leg-tam').value, modelo: $('leg-modelo').value,
        largura_max: 1440, saida: pasta
      };
      var pedArq = path.join(pasta, 'pedido.json');
      fs.writeFileSync(pedArq, JSON.stringify(pedido));
      P.log('Legendas "' + NOMES[est] + '" para ' + al.length + (al.length === 1 ? ' clipe' : ' clipes') + ' (' + P.seg(dur) + ').');
      fase('Transcrevendo a fala…');
      var saida = JSON.parse((await rodar(pedArq)).trim().split('\n').pop());
      checar();
      aplicando = true; $('leg-cancelar').disabled = true; $('leg-cancelar').textContent = 'Colocando… (não dá para cancelar)';
      fase('Colocando na timeline…');
      var r;
      try {
        r = await P.chama('JM.legendaNaTimeline(' + JSON.stringify(saida.arquivo) + ',' + saida.escala_pct + ')', 'colocar a legenda');
      } catch (e) {
        if (/not a function|não é uma função|undefined/i.test(e.message)) throw new Error('o Premiere ainda está com a versão antiga do plugin. Salve o projeto, feche e abra o Premiere e tente de novo.');
        throw e;
      }
      var avisos = [];
      try { await P.chama('JM.salvar()', 'salvar'); } catch (e2) { avisos.push('não consegui salvar o projeto: ' + e2.message); }
      $('lr-palavras').textContent = String(saida.palavras); $('lr-cartoes').textContent = String(saida.cartoes);
      $('lr-trilha').textContent = r.trilha; $('lr-estilo').textContent = NOMES[est];
      $('leg-avisos').innerHTML = '';
      var m = document.createElement('div'); m.className = avisos.length ? 'aviso' : 'ok';
      m.textContent = avisos.length ? 'ATENÇÃO: ' + avisos.join(' ')
        : '✓ Legenda na ' + r.trilha + (r.removidas ? ' (trocou a anterior)' : '') + '. Confira a transcrição: nomes próprios podem vir errados. Projeto salvo.';
      $('leg-avisos').appendChild(m);
      $('leg-resultado').style.display = 'block';
      var s = Math.round((Date.now() - t0) / 1000);
      fase('Pronto em ' + s + ' s.');
      P.log('Legenda pronta em ' + s + ' s: ' + saida.palavras + ' palavras em ' + saida.cartoes + ' legendas, trilha ' + r.trilha + '.', 'ok');
      P.log('Arquivo: ' + saida.arquivo);
    } catch (e) {
      if (e.cancelado) {
        fase('Cancelado.'); P.log('Cancelado pelo usuário.');
        $('leg-avisos').innerHTML = ''; var c = document.createElement('div'); c.className = 'info'; c.textContent = 'Cancelado: a timeline não foi alterada.'; $('leg-avisos').appendChild(c);
        ['lr-palavras', 'lr-cartoes', 'lr-trilha', 'lr-estilo'].forEach(function (id) { $(id).textContent = '–'; }); $('leg-resultado').style.display = 'block';
      } else if (e.suave) {
        fase('Sem fala: nada a legendar.'); P.log(e.message);
        $('leg-avisos').innerHTML = ''; var c2 = document.createElement('div'); c2.className = 'info'; c2.textContent = e.message; $('leg-avisos').appendChild(c2);
        ['lr-palavras', 'lr-cartoes', 'lr-trilha', 'lr-estilo'].forEach(function (id) { $(id).textContent = '–'; }); $('leg-resultado').style.display = 'block';
      } else { fase('Parou: ' + e.message); P.log('Erro: ' + e.message, 'erro'); }
    } finally {
      aplicando = false; proc = null; trabalhando(false); P.lerTimeline(true);
    }
  }

  // ---------- estilo e cor ----------
  Array.prototype.forEach.call(document.querySelectorAll('input[name="leg-estilo"]'), function (r) {
    r.addEventListener('change', function () { if (!corMexida) { $('leg-cor').value = COR_PADRAO[estilo()] || '#ffc400'; } pintaCor(); });
  });
  $('leg-cor').addEventListener('input', function () { corMexida = true; pintaCor(); });
  $('leg-criar').addEventListener('click', criar);
  $('leg-cancelar').addEventListener('click', cancelar);
  window.JMLeg = { atualizar: atualizar };
  pintaCor();
  try { if (window.localStorage.getItem('jm-aba') === 'legendas') aba('legendas'); } catch (e) {}
})();

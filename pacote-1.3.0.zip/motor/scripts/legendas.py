#!/usr/bin/env python3
"""Legendas criativas para a timeline do Premiere.

Lê um pedido JSON (clipes da V1 com entrada/saída/início na timeline), transcreve a fala com Whisper (uma vez por arquivo),
converte o tempo da mídia para o tempo da timeline, agrupa as palavras em "cartões" conforme o estilo e desenha cada quadro
com Pillow, gerando um VÍDEO TRANSPARENTE (ProRes 4444) que o painel coloca numa trilha acima da V1.
Não precisa de libass/drawtext no ffmpeg: o desenho é feito aqui.

Uso: legendas.py pedido.json
pedido: {clips:[{arquivo,entrada,saida,inicio,fim}], largura, altura, fps, duracao, estilo, cor, posicao, tamanho, modelo, saida}
Saída (stdout): JSON com arquivo, largura, altura, escala_pct, palavras, cartoes, duracao.
"""
import json, math, os, re, subprocess, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import analisar as A                      # achar, sonda, extrair_audio, regioes_de_voz, transcrever, aplicar_glossario, carregar_glossario
try:
    from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont
except ImportError:
    print('FALTA_PILLOW', file=sys.stderr)
    sys.exit(4)

FONTES = '/System/Library/Fonts/'
SUP = FONTES + 'Supplemental/'
# (arquivo, nome do estilo dentro do arquivo) em ordem de preferência
PREF = {
    'pesada':  [(SUP + 'Impact.ttf', None), (SUP + 'Arial Black.ttf', None), (FONTES + 'HelveticaNeue.ttc', 'Condensed Black'), (SUP + 'Arial Bold.ttf', None)],
    'negrito': [(FONTES + 'Avenir Next.ttc', 'Heavy'), (FONTES + 'Avenir Next.ttc', 'Demi Bold'), (FONTES + 'HelveticaNeue.ttc', 'Bold'), (SUP + 'Arial Bold.ttf', None)],
    'fina':    [(FONTES + 'HelveticaNeue.ttc', 'Light'), (FONTES + 'Avenir Next.ttc', 'Regular'), (FONTES + 'Helvetica.ttc', 'Light'), (SUP + 'Arial.ttf', None)],
    'media':   [(FONTES + 'Avenir Next.ttc', 'Bold'), (FONTES + 'HelveticaNeue.ttc', 'Bold'), (SUP + 'Arial Bold.ttf', None)],
}
_cache_fonte = {}


def fonte(familia, tamanho):
    chave = (familia, int(tamanho))
    if chave in _cache_fonte:
        return _cache_fonte[chave]
    for caminho, estilo in PREF[familia]:
        if not os.path.exists(caminho):
            continue
        for i in range(0, 24):
            try:
                f = ImageFont.truetype(caminho, int(tamanho), index=i)
            except Exception:
                break
            if estilo is None or f.getname()[1].strip() == estilo:
                _cache_fonte[chave] = f
                return f
    f = ImageFont.load_default()
    _cache_fonte[chave] = f
    return f


def cor_rgb(h, padrao=(255, 196, 0)):
    m = re.fullmatch(r'#?([0-9a-fA-F]{6})', str(h or ''))
    if not m:
        return padrao
    v = m.group(1)
    return (int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))


# ---------------------------------------------------------------- estilos
ESTILOS = {
    # nome: parâmetros
    'impacto':  dict(fam='pesada',  tam=0.112, max_pal=3, max_car=18, maiuscula=True,  trac=0, anim='pop',  linhas_larg=0.88, ativo='cor', stroke=0.085),
    'karaoke':  dict(fam='negrito', tam=0.060, max_pal=8, max_car=36, maiuscula=False, trac=0, anim='fade', linhas_larg=0.84, ativo='cor', stroke=0.0, futuras=0.55),
    'elegante': dict(fam='fina',    tam=0.058, max_pal=7, max_car=34, maiuscula=False, trac=1.5, anim='fade_sobe', linhas_larg=0.80, ativo='cor', stroke=0.0, fade_out=True),
    'tarja':    dict(fam='media',   tam=0.054, max_pal=5, max_car=26, maiuscula=False, trac=0, anim='desliza', linhas_larg=0.80, ativo='nenhum', stroke=0.0, caixa=True),
}
ANIM = 5          # quadros da animação de entrada
SAIDA_FADE = 3    # quadros do fade de saída
POSICAO = {'baixo': 0.72, 'centro': 0.50, 'alto': 0.20}
TAMANHO = {'pequeno': 0.8, 'medio': 1.0, 'grande': 1.25}


def facil_pop(p):
    c1 = 1.70158
    c3 = c1 + 1
    p = max(0.0, min(1.0, p))
    return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2


def facil_sai(p):
    p = max(0.0, min(1.0, p))
    return 1 - (1 - p) ** 3


# ---------------------------------------------------------------- cartões
def montar_cartoes(palavras, est):
    cartoes, atual = [], []

    def fecha():
        nonlocal atual
        if atual:
            cartoes.append(atual)
            atual = []
    for p in palavras:
        if atual:
            texto = ' '.join(x['w'] for x in atual + [p])
            lacuna = p['tl0'] - atual[-1]['tl1']
            final = re.search(r'[.!?;]$', atual[-1]['w'])
            virgula = re.search(r',$', atual[-1]['w']) and len(atual) >= 3
            if lacuna > 0.55 or final or virgula or len(atual) >= est['max_pal'] or len(texto) > est['max_car']:
                fecha()
        atual.append(p)
    fecha()
    out = []
    for i, c in enumerate(cartoes):
        ini = max(0.0, c[0]['tl0'] - 0.04)
        fim = c[-1]['tl1'] + 0.28
        if i + 1 < len(cartoes):
            fim = min(fim, cartoes[i + 1][0]['tl0'] - 0.04 + 0.04)
            fim = max(fim, c[-1]['tl1'])
        fim = max(fim, ini + 0.35)
        out.append(dict(palavras=c, ini=ini, fim=fim))
    # nunca sobrepor o cartão seguinte
    for i in range(len(out) - 1):
        if out[i]['fim'] > out[i + 1]['ini']:
            out[i]['fim'] = max(out[i + 1]['ini'], out[i]['ini'] + 0.2)
    return out


# ---------------------------------------------------------------- desenho
def largura(f, texto, trac):
    if not trac:
        return f.getlength(texto)
    return sum(f.getlength(ch) + trac for ch in texto) - trac if texto else 0


def escreve(d, xy, texto, f, preench, trac=0, stroke=0, stroke_cor=(0, 0, 0, 255)):
    x, y = xy
    if not trac:
        d.text((x, y), texto, font=f, fill=preench, stroke_width=stroke, stroke_fill=stroke_cor)
        return
    for ch in texto:
        d.text((x, y), ch, font=f, fill=preench, stroke_width=stroke, stroke_fill=stroke_cor)
        x += f.getlength(ch) + trac


def desenha_cartao(est, ctx, cartao, ativo):
    """Devolve a camada RGBA (justa) do cartão com a palavra `ativo` em destaque."""
    f = ctx['fonte']
    trac = est['trac'] * ctx['k']
    palavras = [(p['w'].upper() if est['maiuscula'] else p['w']) for p in cartao['palavras']]
    espaco = f.getlength(' ') + trac
    larg_max = ctx['rw'] * est['linhas_larg']
    linhas, linha, w_linha = [], [], 0
    for i, txt in enumerate(palavras):
        w = largura(f, txt, trac)
        if linha and w_linha + espaco + w > larg_max:
            linhas.append((linha, w_linha)); linha, w_linha = [], 0
        w_linha += (espaco if linha else 0) + w
        linha.append((i, txt, w))
    if linha:
        linhas.append((linha, w_linha))
    alt_linha = ctx['tam_px'] * 1.2
    pad = int(ctx['tam_px'] * (0.55 if est.get('caixa') else 0.45))
    bw = int(max(w for _, w in linhas)) + 2 * pad
    bh = int(alt_linha * len(linhas)) + 2 * pad
    camada = Image.new('RGBA', (bw, bh), (0, 0, 0, 0))
    sombra = Image.new('RGBA', (bw, bh), (0, 0, 0, 0))
    d, ds = ImageDraw.Draw(camada), ImageDraw.Draw(sombra)
    branco, cor = (255, 255, 255, 255), ctx['cor'] + (255,)
    stroke = int(round(ctx['tam_px'] * est.get('stroke', 0)))
    if est.get('caixa'):
        r = int(ctx['tam_px'] * 0.35)
        d.rounded_rectangle((0, 0, bw - 1, bh - 1), radius=r, fill=cor)
    for li, (ws, wl) in enumerate(linhas):
        x = pad + (bw - 2 * pad - wl) / 2
        y = pad + li * alt_linha + (alt_linha - ctx['tam_px']) * 0.2
        for i, txt, w in ws:
            if est.get('caixa'):
                preench = (15, 12, 6, 255)
            elif est['ativo'] == 'cor' and i == ativo:
                preench = cor
            elif est.get('futuras') and i > ativo:
                preench = (255, 255, 255, int(255 * est['futuras']))
            else:
                preench = branco
            if not est.get('caixa'):
                escreve(ds, (x + ctx['tam_px'] * 0.03, y + ctx['tam_px'] * 0.05), txt, f, (0, 0, 0, 200), trac, stroke)
            escreve(d, (x, y), txt, f, preench, trac, stroke)
            x += w + espaco
    if not est.get('caixa'):
        sombra = sombra.filter(ImageFilter.GaussianBlur(max(1, ctx['tam_px'] * 0.035)))
        camada = Image.alpha_composite(sombra, camada)
    return camada


def compoe_estado(est, ctx, cartao, ativo, ai, ao):
    camada = desenha_cartao(est, ctx, cartao, ativo)
    p = min(1.0, ai / float(ANIM))
    escala, alfa, dy = 1.0, 1.0, 0.0
    if est['anim'] == 'pop':
        escala = 0.7 + 0.3 * facil_pop(p); alfa = min(1.0, p * 2.2)
    elif est['anim'] == 'fade':
        alfa = facil_sai(p)
    elif est['anim'] == 'fade_sobe':
        alfa = facil_sai(p); dy = (1 - facil_sai(p)) * ctx['tam_px'] * 0.35
    elif est['anim'] == 'desliza':
        alfa = facil_sai(p); dy = (1 - facil_sai(p)) * ctx['tam_px'] * 0.9
    if est.get('fade_out') and ao < SAIDA_FADE:
        alfa *= max(0.0, ao / float(SAIDA_FADE))
    if escala != 1.0:
        camada = camada.resize((max(1, int(camada.width * escala)), max(1, int(camada.height * escala))), Image.LANCZOS)
    if alfa < 0.999:
        a = camada.getchannel('A').point(lambda v: int(v * alfa))
        camada.putalpha(a)
    tela = Image.new('RGBA', (ctx['rw'], ctx['rh']), (0, 0, 0, 0))
    cx = ctx['rw'] / 2.0
    cy = ctx['rh'] * ctx['pos_y'] + dy
    x = int(round(cx - camada.width / 2.0))
    y = int(round(cy - camada.height / 2.0))
    x = max(0, min(ctx['rw'] - camada.width, x))
    y = max(0, min(ctx['rh'] - camada.height, y))
    tela.alpha_composite(camada, dest=(x, y))
    return tela


# ---------------------------------------------------------------- transcrição
def transcrever_clipes(clips, modelo, saida, log):
    glossario = A.carregar_glossario()
    por_arquivo = {}
    for c in clips:
        e = por_arquivo.setdefault(c['arquivo'], [c['entrada'], c['saida']])
        e[0] = min(e[0], c['entrada']); e[1] = max(e[1], c['saida'])
    palavras_arquivo = {}
    for n, (arq, (de, ate)) in enumerate(por_arquivo.items()):
        log('Transcrevendo %d de %d (a transcrição leva cerca de 1× a duração do trecho)…' % (n + 1, len(por_arquivo)))
        wav = os.path.join(saida, 'voz%d.wav' % n)
        x, sr = A.extrair_audio(arq, wav, de, ate)
        regs, _ = A.regioes_de_voz(x, sr, 27)
        pal = A.transcrever(wav, modelo, glossario)
        ok = []
        for p in pal:
            meio = (p['t0'] + p['t1']) / 2.0
            if any(a - 0.05 <= meio <= b + 0.05 for a, b in regs):
                ok.append(dict(t0=p['t0'] + de, t1=p['t1'] + de, w=p['w']))
        palavras_arquivo[arq] = ok
        try:
            os.remove(wav)
        except OSError:
            pass
    return palavras_arquivo, glossario


def para_timeline(clips, palavras_arquivo):
    out = []
    for c in sorted(clips, key=lambda c: c['inicio']):
        for p in palavras_arquivo.get(c['arquivo'], []):
            meio = (p['t0'] + p['t1']) / 2.0
            if c['entrada'] - 0.02 <= meio <= c['saida'] + 0.02:
                t0 = c['inicio'] + (p['t0'] - c['entrada'])
                t1 = c['inicio'] + (p['t1'] - c['entrada'])
                t0 = max(c['inicio'], t0); t1 = min(c['fim'], max(t1, t0 + 0.05))
                out.append(dict(w=p['w'], tl0=round(t0, 3), tl1=round(t1, 3)))
    out.sort(key=lambda p: p['tl0'])
    return out


def aplicar_glossario_cartao(cartao, glossario):
    ws = cartao['palavras']
    novo = A.aplicar_glossario(' '.join(p['w'] for p in ws), glossario).split()
    if len(novo) == len(ws):
        for p, n in zip(ws, novo):
            p['w'] = n


# ---------------------------------------------------------------- principal
def main():
    ped = json.load(open(sys.argv[1], encoding='utf-8'))
    t_ini = time.time()
    est = dict(ESTILOS.get(ped.get('estilo'), ESTILOS['impacto']))
    saida = ped['saida']
    os.makedirs(saida, exist_ok=True)

    def log(t):
        print('@@' + t, file=sys.stderr, flush=True)

    clips = ped['clips']
    palavras_arquivo, glossario = transcrever_clipes(clips, ped.get('modelo', 'medium'), saida, log)
    palavras = para_timeline(clips, palavras_arquivo)
    if not palavras:
        print(json.dumps(dict(erro='sem_fala', mensagem='Não achei fala nos clipes: nada para legendar.'), ensure_ascii=False))
        sys.exit(3)
    cartoes = montar_cartoes(palavras, est)
    for c in cartoes:
        aplicar_glossario_cartao(c, glossario)

    W, H = int(ped['largura']), int(ped['altura'])
    fps = float(ped.get('fps') or 0) or A.sonda(clips[0]['arquivo'])['fps']
    dur = float(ped.get('duracao') or max(c['fim'] for c in clips))
    rw = min(W, int(ped.get('largura_max', 1440)))
    rw -= rw % 2
    rh = int(round(H * rw / float(W))); rh -= rh % 2
    k = rw / 1080.0
    tam_px = est['tam'] * rw * TAMANHO.get(ped.get('tamanho'), 1.0)
    ctx = dict(rw=rw, rh=rh, k=k, tam_px=tam_px, fonte=fonte(est['fam'], tam_px), cor=cor_rgb(ped.get('cor')),
               pos_y=POSICAO.get(ped.get('posicao'), 0.72))

    pasta = os.path.join(saida, 'quadros')
    os.makedirs(pasta, exist_ok=True)
    vazio = os.path.join(pasta, 'vazio.png')
    Image.new('RGBA', (rw, rh), (0, 0, 0, 0)).save(vazio, 'PNG', compress_level=1)
    nq = int(round(dur * fps))
    estados, seq = {}, []
    ci = 0
    log('Desenhando as legendas…')
    for f in range(nq):
        t = f / fps
        while ci < len(cartoes) and t >= cartoes[ci]['fim']:
            ci += 1
        if ci >= len(cartoes) or t < cartoes[ci]['ini']:
            seq.append(vazio); continue
        c = cartoes[ci]
        ativo = 0
        for i, p in enumerate(c['palavras']):
            if p['tl0'] - 0.03 <= t:
                ativo = i
        ai = int((t - c['ini']) * fps)
        ai = min(ai, ANIM)
        resta = int((c['fim'] - t) * fps)
        ao = resta if resta < SAIDA_FADE else 99
        chave = (ci, ativo, ai, ao)
        if chave not in estados:
            caminho = os.path.join(pasta, 'q%05d.png' % len(estados))
            compoe_estado(est, ctx, c, ativo, ai, ao).save(caminho, 'PNG', compress_level=1)
            estados[chave] = caminho
        seq.append(estados[chave])
        if f % 150 == 0:
            log('Desenhando as legendas… %d%%' % (100 * f // max(1, nq)))

    # lista para o ffmpeg (quadros repetidos viram uma duração só)
    lista = os.path.join(saida, 'lista.txt')
    with open(lista, 'w') as fl:
        i = 0
        while i < len(seq):
            j = i
            while j < len(seq) and seq[j] == seq[i]:
                j += 1
            fl.write("file '%s'\nduration %.6f\n" % (seq[i].replace("'", "'\\''"), (j - i) / fps))
            i = j
        fl.write("file '%s'\n" % seq[-1].replace("'", "'\\''"))
    nome = 'JM-legenda-%s-%s.mov' % (ped.get('estilo', 'impacto'), time.strftime('%Y%m%d-%H%M%S'))
    destino = os.path.join(saida, nome)
    log('Gerando o vídeo transparente…')
    subprocess.check_call([A.achar('ffmpeg'), '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', lista,
                           '-vf', 'fps=%.6f,format=yuva444p10le' % fps, '-frames:v', str(nq),
                           '-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0', destino])
    try:
        for q in os.listdir(pasta):
            os.remove(os.path.join(pasta, q))
        os.rmdir(pasta)
    except OSError:
        pass
    json.dump(dict(palavras=palavras, cartoes=[dict(ini=round(c['ini'], 3), fim=round(c['fim'], 3), texto=' '.join(p['w'] for p in c['palavras'])) for c in cartoes]),
              open(os.path.join(saida, 'legendas.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(json.dumps(dict(arquivo=destino, largura=rw, altura=rh, escala_pct=round(W * 100.0 / rw, 2), palavras=len(palavras),
                          cartoes=len(cartoes), estados=len(estados), duracao=round(dur, 2), fps=round(fps, 3),
                          estilo=ped.get('estilo', 'impacto'), tempo_s=round(time.time() - t_ini, 1)), ensure_ascii=False))


if __name__ == '__main__':
    main()

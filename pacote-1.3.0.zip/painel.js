/* JM Editor — botão "Editar a timeline" dentro do Premiere.
 * Pega o que JÁ ESTÁ na timeline (V1) -> motor (Python + Whisper) acha a fala e decide os cortes secos ->
 * troca cada clipe pelos seus trechos (+ zoom alternado) -> confere -> salva.
 * Antes de mexer, faz uma cópia de segurança da sequência (opção ligada por padrão).
 * Legenda e cor: em espera (estilo novo a caminho).
 */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  if (!$('editar')) return;
  var req = (typeof require !== 'undefined') ? require : (window.cep_node && window.cep_node.require);
  var cep = window.__adobe_cep__;
  if (!req || !cep) { $('log').textContent = 'Painel sem Node/CEP: reinstale a extensão (scripts/instalar-ponte.sh).'; return; }
  var cp = req('child_process'), fs = req('fs'), path = req('path'), os = req('os');

  // Python próprio criado pelo instalador (~/.jm-ponte/venv); sem ele, o do sistema (precisa de numpy + faster-whisper)
  var PYTHON_VENV = path.join(os.homedir(), '.jm-ponte', 'venv', 'bin', 'python3');
  var PYTHON = fs.existsSync(PYTHON_VENV) ? PYTHON_VENV : '/usr/bin/python3';
  var raiz = (function () {
    try { return decodeURI(cep.getSystemPath('extension')).replace(/^file:\/\//, ''); } catch (e) { return path.dirname(decodeURI(location.pathname)); }
  })();
  var MOTOR = path.join(raiz, 'motor', 'scripts', 'analisar.py');
  var tl = null;        // estado da timeline
  var ocupado = false;

  // ---------- utilidades de tela ----------
  function log(t, cls) {
    var d = document.createElement('div'); if (cls) d.className = cls; d.textContent = t;
    $('log').appendChild(d); $('log').scrollTop = $('log').scrollHeight;
  }
  function seg(s) { s = Math.round(s * 10) / 10; var m = Math.floor(s / 60); var r = (s - m * 60); return m ? m + ':' + (r < 10 ? '0' : '') + r.toFixed(1).replace('.', ',') : r.toFixed(1).replace('.', ',') + ' s'; }
  function etapa(n) {
    for (var i = 1; i <= 4; i++) { var e = $('e' + i); e.className = 'etapa' + (i < n ? ' feita' : i === n ? ' ativa' : ''); }
  }
  function fase(t) { $('fase').textContent = t; }
  var cancelado = false, procAtual = null, aplicando = false;
  function checar() { if (cancelado) { var c = new Error('Cancelado. Nada foi alterado na timeline.'); c.cancelado = true; throw c; } }
  function cancelar() {
    if (!ocupado || cancelado) return;
    if (aplicando) { log('Já está aplicando os cortes: não dá para cancelar agora. Use ⌘Z para desfazer.', 'erro'); return; }
    cancelado = true; $('cancelar').disabled = true; $('cancelar').textContent = 'Cancelando…'; fase('Cancelando…');
    if (procAtual) { try { process.kill(-procAtual.pid, 'SIGTERM'); } catch (e) { try { procAtual.kill('SIGTERM'); } catch (e2) {} } }
  }
  function trabalhando(on) {
    ocupado = on; $('barra').className = 'barra' + (on ? ' on' : '');
    $('editar').className = on ? 'trabalhando' : '';
    $('editar-txt').textContent = on ? 'Editando…' : 'Editar a timeline';
    $('atualizar').disabled = on;
    $('cancelar').className = on ? 'on' : ''; $('cancelar').disabled = false; $('cancelar').textContent = 'Cancelar';
    if (on) cancelado = false;
    $('editar').disabled = on || !alvos().length;
  }
  function jsx(codigo) {
    return new Promise(function (ok) {
      cep.evalScript('JM_run(' + JSON.stringify(codigo) + ')', function (r) {
        try { ok(JSON.parse(r)); } catch (e) { ok({ ok: false, erro: 'resposta inválida do Premiere: ' + String(r).slice(0, 160) }); }
      });
    });
  }
  async function chama(codigo, rotulo) {
    var r = await jsx(codigo);
    if (!r.ok) throw new Error((rotulo ? rotulo + ': ' : '') + r.erro + (r.linha ? ' (linha ' + r.linha + ')' : ''));
    return r.v;
  }

  // ---------- timeline ----------
  function alvos() {
    if (!tl || !tl.clipes) return [];
    return tl.clipes.filter(function (c) { return c.caminho && (!tl.temSelecao || c.selecionado); });
  }
  function desenhar() {
    var box = $('clipes'); box.innerHTML = '';
    if (!tl || !tl.sequencia) {
      $('seq').textContent = 'Nenhuma sequência aberta'; $('seqinfo').textContent = 'Abra uma sequência com o vídeo na timeline.'; $('alvoinfo').textContent = '';
      $('editar').disabled = true; return;
    }
    $('seq').textContent = tl.sequencia;
    var wh = tl.larguraAltura ? ' · ' + tl.larguraAltura[0] + '×' + tl.larguraAltura[1] : '';
    $('seqinfo').textContent = tl.clipes.length + (tl.clipes.length === 1 ? ' clipe' : ' clipes') + ' na V1 · ' + seg(tl.duracao || 0) + wh;
    var al = alvos();
    tl.clipes.forEach(function (c) {
      var d = document.createElement('div');
      var eAlvo = al.indexOf(c) >= 0;
      d.className = 'clipe' + (c.selecionado ? ' sel' : '') + (eAlvo ? ' alvo' : '');
      var i = document.createElement('i'), n = document.createElement('span'), t = document.createElement('em');
      n.textContent = c.nome; t.textContent = seg(c.fim - c.inicio);
      d.appendChild(i); d.appendChild(n); d.appendChild(t); box.appendChild(d);
    });
    $('alvoinfo').textContent = !tl.clipes.length ? 'A timeline está vazia.'
      : !al.length ? 'Nenhum clipe com mídia para editar.'
      : (tl.temSelecao ? 'Vai editar só o que está selecionado (' + al.length + ').' : 'Vai editar tudo o que está na V1 (' + al.length + ').');
    if (!ocupado) $('editar').disabled = !al.length;
    if (window.JMLeg) window.JMLeg.atualizar();
  }
  async function lerTimeline(silencioso) {
    if (ocupado) return;
    try { tl = await chama('JM.timeline()', 'timeline'); desenhar(); }
    catch (e) { if (!silencioso) log(e.message, 'erro'); tl = null; desenhar(); }
  }

  // ---------- motor ----------
  function rodarMotor(arq, de, ate, saida, opts, aoEtapa) {
    return new Promise(function (ok, falha) {
      var args = [MOTOR, arq, '--saida', saida, '--modelo', opts.modelo, '--de', String(de), '--ate', String(ate), '--modo', opts.modo, '--max-plano', String(opts.ritmo)];
      if (opts.modo === 'sem-fala' && opts.alvo > 0) args.push('--alvo', String(opts.alvo));
      if (!opts.zoom) args.push('--sem-zoom');
      var env = Object.assign({}, process.env, { PATH: path.join(os.homedir(), '.jm-ponte', 'bin') + ':/opt/homebrew/bin:/usr/local/bin:' + (process.env.PATH || '') });
      var p = cp.spawn(PYTHON, args, { env: env, detached: true });
      procAtual = p;
      var out = '', err = '';
      p.stdout.on('data', function (d) { out += d; });
      p.stderr.on('data', function (d) {
        err += d;
        String(d).split('\n').forEach(function (l) { if (l.indexOf('@@') === 0) aoEtapa(l.slice(2).trim()); });
      });
      p.on('error', function (e) { falha(e); });
      p.on('close', function (c) {
        procAtual = null;
        if (cancelado) { var ce = new Error('Cancelado. Nada foi alterado na timeline.'); ce.cancelado = true; return falha(ce); }
        if (c === 0) ok(out);
        else falha(new Error('o motor de análise falhou (código ' + c + '): ' + err.split('\n').filter(function (l) { return l && l.indexOf('Warning') < 0 && l.indexOf('mel_spec') < 0; }).slice(-4).join(' | ')));
      });
    });
  }
  function agora() {
    var z = function (n) { return (n < 10 ? '0' : '') + n; }, d = new Date();
    return z(d.getHours()) + 'h' + z(d.getMinutes());
  }

  // ---------- fluxo principal ----------
  async function editar() {
    if (ocupado) return;
    var al = alvos();
    if (!al.length) return;
    trabalhando(true); $('resultado').style.display = 'none'; $('avisos').innerHTML = '';
    var t0 = Date.now();
    try {
      if (!fs.existsSync(PYTHON)) throw new Error('Python não encontrado em ' + PYTHON + '. Rode o Instalar.command de novo.');
      if (!fs.existsSync(MOTOR)) throw new Error('motor de análise ausente. Rode o Instalar.command (ou scripts/instalar-ponte.sh) de novo.');
      var opts = { modelo: $('modelo').value, zoom: $('zoom').checked, modo: $('modo').value, ritmo: $('ritmo').value, alvo: 0 };
      var semFala = opts.modo === 'sem-fala';
      var totalV1 = tl.clipes.length;
      var nomeSeq = tl.sequencia;

      // 0) cópia de segurança
      if ($('backup').checked) {
        fase('Guardando uma cópia de segurança da sequência…'); etapa(1);
        var bk = await chama('JM.copiaSeguranca(' + JSON.stringify('JM backup — ' + nomeSeq + ' — ' + agora()) + ')', 'cópia de segurança');
        log('Cópia de segurança: "' + bk.copia + '"', 'ok');
      } else log('Sem cópia de segurança (opção desligada).');
      checar();

      // 1) analisar cada clipe (só a parte da mídia que a timeline usa)
      etapa(1);
      var pedidos = [], planos = [];
      var alvoTotal = semFala ? Number($('alvo').value) : 0;
      var somaDur = al.reduce(function (s, x) { return s + (x.saida - x.entrada); }, 0) || 1;
      for (var i = 0; i < al.length; i++) {
        var c = al[i];
        checar();
        if (!fs.existsSync(c.caminho)) throw new Error('mídia offline: ' + c.caminho);
        var base = path.basename(c.caminho).replace(/\.[^.]+$/, '');
        var saida = path.join(os.homedir(), 'Movies', 'JM Premiere', base + '-' + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '') + '-c' + c.indice);
        var rotulo = al.length > 1 ? 'Clipe ' + (i + 1) + ' de ' + al.length + ': ' : '';
        log('Analisando "' + c.nome + '" (' + seg(c.saida - c.entrada) + ')');
        opts.alvo = alvoTotal > 0 ? Math.max(2, alvoTotal * (c.saida - c.entrada) / somaDur) : 0;
        await rodarMotor(c.caminho, c.entrada, c.saida, saida, opts, function (e) { fase(rotulo + e); log('· ' + e); });
        var plano = JSON.parse(fs.readFileSync(path.join(saida, 'plano.json'), 'utf8'));
        if (!plano.trechos.length) { log((semFala ? 'Nenhum plano aproveitável em "' : 'Sem fala em "') + c.nome + '": mantido como está.'); continue; }
        planos.push(plano);
        if (semFala && plano.ritmo) log(plano.ritmo.batida ? '♪ Música com ritmo: ' + Math.round(plano.ritmo.bpm) + ' batidas/min — cortes na batida (' + plano.ritmo.batidas_por_corte + ' batidas por plano).' : 'Sem ritmo de música claro (ou sem áudio): planos de tamanho fixo.', plano.ritmo.batida ? 'ok' : '');
        pedidos.push({ indice: c.indice, trechos: plano.trechos.map(function (t) { return { de: t.de, ate: t.ate, zoom: t.zoom }; }) });
      }
      if (!pedidos.length) { var sf = new Error(semFala ? 'Não encontrei planos para cortar. Nada foi alterado.' : 'Nenhuma fala encontrada nos clipes, então não há o que cortar. Nada foi alterado. Se o vídeo não tem voz, troque "Tipo de vídeo" para "Sem fala" e clique de novo.'); sf.suave = true; throw sf; }

      // 2) aplicar na timeline
      checar();
      aplicando = true; $('cancelar').disabled = true; $('cancelar').textContent = 'Aplicando… (não dá para cancelar)';
      etapa(2); fase('Cortando na timeline…');
      var juntar = pedidos.length === totalV1;
      var r = await chama('JM.editarNaTimeline(' + JSON.stringify(pedidos) + ',' + (juntar ? 'true' : 'false') + ')', 'editar a timeline');
      etapa(3); fase('Aplicando o zoom…');
      log(r.colocados + ' trechos colocados, ' + r.comZoom + ' com zoom.');

      // 3) conferir
      etapa(4); fase('Conferindo o resultado…');
      var depois = await chama('JM.timeline()', 'conferir');
      var esperado = (totalV1 - pedidos.length) + planos.reduce(function (s, p) { return s + p.trechos.length; }, 0);
      var avisos = [];
      if (depois.clipes.length !== esperado) avisos.push('esperava ' + esperado + ' clipes na V1 e há ' + depois.clipes.length + '.');
      var resumo = await chama('JM.resumo()', 'conferir áudio');
      var a1 = resumo.filter(function (x) { return x.trilha === 'A1'; });
      if (!a1.length) avisos.push('o áudio NÃO veio para a A1: confira o alvo de áudio da sequência (⌘Z desfaz).');
      else if (a1.length < depois.clipes.length) avisos.push('há ' + a1.length + ' clipes de áudio na A1 para ' + depois.clipes.length + ' de vídeo.');
      try { await chama('JM.salvar()', 'salvar'); } catch (e) { avisos.push('não consegui salvar o projeto: ' + e.message); }

      // resultado
      var antes = planos.reduce(function (s, p) { return s + p.duracao_original; }, 0);
      var dep = planos.reduce(function (s, p) { return s + p.duracao_final; }, 0);
      var rem = planos.reduce(function (s, p) { return s + (semFala ? Math.max(0, p.trechos.length - 1) : p.removidos.length); }, 0);
      $('n-antes').textContent = seg(antes); $('n-depois').textContent = seg(dep);
      $('n-cortes').textContent = String(r.colocados); $('n-removidos').textContent = String(rem);
      $('avisos').innerHTML = '';
      var msg = document.createElement('div'); msg.className = avisos.length ? 'aviso' : 'ok';
      msg.textContent = avisos.length ? 'ATENÇÃO: ' + avisos.join(' ') : '✓ Conferido: clipes, duração e áudio batem com o plano. Projeto salvo.';
      $('avisos').appendChild(msg);
      $('resultado').style.display = 'block';
      etapa(5); fase('Pronto em ' + Math.round((Date.now() - t0) / 1000) + ' s.');
      log('Pronto em ' + Math.round((Date.now() - t0) / 1000) + ' s: ' + r.colocados + ' trechos, ' + seg(antes) + ' → ' + seg(dep) + '.', 'ok');
      avisos.forEach(function (a) { log('ATENÇÃO: ' + a, 'erro'); });
    } catch (e) {
      etapa(0);
      if (e.cancelado) {
        fase('Cancelado.');
        $('avisos').innerHTML = ''; var m3 = document.createElement('div'); m3.className = 'info'; m3.textContent = 'Cancelado: a timeline não foi alterada.' + ($('backup').checked && typeof bk !== 'undefined' && bk ? ' A cópia de segurança "' + bk.copia + '" foi criada antes e pode ser apagada.' : ''); $('avisos').appendChild(m3);
        $('resultado').style.display = 'block';
        ['n-antes', 'n-depois', 'n-cortes', 'n-removidos'].forEach(function (id) { $(id).textContent = '–'; });
        log('Cancelado pelo usuário.');
      } else if (e.suave) {
        fase('Sem fala: nada a cortar.');
        $('avisos').innerHTML = ''; var m2 = document.createElement('div'); m2.className = 'info'; m2.textContent = e.message; $('avisos').appendChild(m2);
        $('resultado').style.display = 'block';
        ['n-antes', 'n-depois', 'n-cortes', 'n-removidos'].forEach(function (id) { $(id).textContent = '–'; });
        log(e.message);
      } else {
        fase('Parou: ' + e.message);
        log('Erro: ' + e.message, 'erro');
      }
    } finally {
      aplicando = false; procAtual = null; trabalhando(false); lerTimeline(true);
    }
  }

  function aplicarModo() {
    var sem = $('modo').value === 'sem-fala';
    $('linha-modelo').style.display = sem ? 'none' : 'flex';
    $('linha-ritmo').style.display = sem ? 'flex' : 'none';
    $('linha-alvo').style.display = sem ? 'flex' : 'none';
    $('removidos-rotulo').textContent = sem ? 'Pulos' : 'Removidos';
  }
  $('modo').addEventListener('change', aplicarModo);
  $('editar').addEventListener('click', editar);
  $('cancelar').addEventListener('click', cancelar);
  $('atualizar').addEventListener('click', function () { lerTimeline(false); });
  window.addEventListener('focus', function () { lerTimeline(true); });
  setInterval(function () { if (!ocupado) lerTimeline(true); }, 5000);
  aplicarModo();
  etapa(0);
  // ponte para a aba Legendas (legendas.js)
  window.JMPainel = {
    chama: chama, log: log, seg: seg, alvos: alvos, lerTimeline: lerTimeline, raiz: raiz, python: PYTHON,
    getTl: function () { return tl; }, ocupado: function () { return ocupado; },
    bloquear: function (on) { ocupado = on; $('atualizar').disabled = on; $('editar').disabled = on || !alvos().length; }
  };
  lerTimeline(false);
})();
